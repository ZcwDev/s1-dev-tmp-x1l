#!/usr/bin/env python3
"""S1-Real-v2 **压测脚本**（只负责施压与采集，不做判分）。

与评测脚本的分工：
  · 本脚本：冻结 cohort → 物化 payload → 按 replay_gap 施压 N 个 Agent 槽 → 逐请求落盘原始量
  · s1_score.py：读原始量离线判分（可反复重跑，不必重新施压）

产出（`--out-dir` 下）：
  raw_<set>_N<n>_<ts>.jsonl    逐请求原始记录（含引擎返回的全部量）
  run_<set>_N<n>_<ts>.json     运行配置 / wall / 计数 / cohort SHA

必须实现的唯一函数：`call_engine(ctx, prompt, max_tokens)` —— 见其 docstring。
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import s1_auth_preflight  # noqa: E402
except ImportError:  # local-auth transport fork can run without embedded probe module
    s1_auth_preflight = None
from s1_common import (ERR_HARNESS_DATA, ERR_HARNESS_RENDER, ERR_INFRA, Renderer,  # noqa: E402
                       classify, ensure_bodies, freeze_cohort, load_index,
                       serving_accounting)


def _engine_headers(extra=None):
    """Add optional secret-backed transport authentication headers."""
    headers = dict(extra or {})
    token = os.environ.get("S1_ENGINE_AUTH_TOKEN", "")
    if token:
        headers["Authorization"] = token
    return headers


# --------------------------------------------------------------------------- #
# 唯一需要你写的函数
# --------------------------------------------------------------------------- #
def _float_field(meta, key):
    value = meta.get(key)
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None


def extract_server_timing(first_meta: dict, final_meta: dict) -> dict:
    """Extract SGLang request timing emitted by ``--enable-metrics``.

    SGLang emits scheduler timestamps on the first streamed event and the API
    receive timestamp on the terminal event.  Keep all timestamps in the
    server's realtime clock domain; never mix them with ``perf_counter()``.
    """
    recv = _float_field(final_meta, "request_received_ts")
    admit = _float_field(final_meta, "api_server_dispatch_finish_ts")
    exec_start = _float_field(first_meta, "forward_entry_time")
    first_token = _float_field(first_meta, "prefill_finished_time")
    if first_token is None:
        # This is just after token production but still server-side, and is a
        # better formal fallback than the client-observed first SSE time.
        first_token = _float_field(first_meta, "response_sent_to_client_ts")
    server_ttft = first_token - recv if recv is not None and first_token is not None else None
    if server_ttft is not None and server_ttft < 0:
        server_ttft = None
    return {
        "t_recv_s": recv,
        "t_admit_s": admit,
        "t_exec_start_s": exec_start,
        "t_first_token_s": first_token,
        "queue_time_s": _float_field(first_meta, "queue_time"),
        "server_ttft_s": server_ttft,
    }


def classify_no_token_finish_reason(finish_reason) -> str:
    """Keep zero-token termination diagnosable without inventing a cause.

    SGLang versions have emitted ``finish_reason`` as either a string or a
    small object.  Treat only explicit text as authoritative; everything else
    remains ``unknown`` rather than being mislabeled as a timeout or OOM.
    """
    if finish_reason is None:
        return "unknown"
    try:
        text = json.dumps(finish_reason, ensure_ascii=False, sort_keys=True).lower()
    except (TypeError, ValueError):
        text = str(finish_reason).lower()
    if "out of memory" in text or "oom" in text:
        return "oom_abort"
    if "queue" in text and any(word in text for word in ("abort", "cancel", "retract")):
        return "queue_abort"
    if "client" in text and any(word in text for word in ("abort", "cancel", "disconnect")):
        return "client_abort"
    return "unknown"


def call_engine(ctx: dict, prompt: str, max_tokens: int) -> dict:
    """通过 SGLang ``/generate`` SSE 调用目标部署跑一次 prefill+decode。

    ctx：
      {"req_id","session_id","prefix_family_id","cache_namespace","routing_key",
       "model","max_output_i","phase"}
      · routing_key 只**携带**；实际副本亲和由 serving 侧 router 决定，本脚本不预判
      · cache_namespace 用于隔离：A/B 与各 N 档必须是不同的值

    必须返回：
      {"ttft_s","prompt_tokens","cached_tokens","output_tokens","tpot_s","error"}

    ★ TTFT 口径：正式通道 = **服务端收到请求 → 首 token**，**包含**引擎 admission/queue/
      scheduling；排除客户端/网络/网关那一段。开发通道若拿不到服务端打点，可临时用客户端
      首 SSE 作 proxy_ttft，但必须显式标注、不得据此发布正式 SLO。

    强烈建议同时返回（用于把"计算瓶颈"与"调度排队"分开；缺省则该维度不判）：
      t_recv_s / t_admit_s / t_exec_start_s / t_first_token_s / ttft_client_s

    ★ 输出负载：容量臂请按 ctx["max_output_i"] 驱动并优先 ignore_eos=true，
      使基线与候选承担相同 decode 工作量。理由：max_output_i 是在该请求自己的
      (phase, 输出档) 格子里从历史输出分布抽样得到的目标长度 —— 与历史**同分布**
      （总量比 0.996）但**逐请求不等**（恰好相等仅 0.38%，≥实际恰好 50.0%）。
    """
    base = os.environ.get("S1_ENGINE_URL", "").rstrip("/")
    if not base:
        raise RuntimeError("INFRA:S1_ENGINE_URL is required")
    timeout = float(os.environ.get("S1_REQUEST_TIMEOUT_S", "1200"))
    payload = {
        "text": prompt,
        "sampling_params": {
            "max_new_tokens": int(max_tokens),
            "temperature": 0,
            "ignore_eos": True,
        },
        "stream": True,
        "rid": ctx["req_id"],
    }
    headers = _engine_headers({
        "Content-Type": "application/json",
        "X-S1-Request-ID": ctx["req_id"],
        "X-S1-Session-ID": str(ctx["session_id"]),
        "X-S1-Cache-Namespace": str(ctx["cache_namespace"]),
    })
    if ctx.get("routing_key"):
        headers["X-S1-Routing-Key"] = str(ctx["routing_key"])
    request = urllib.request.Request(
        base + "/generate",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    started = time.perf_counter()
    first_at = final_at = None
    first_meta = final_meta = None
    final_event = None
    event_count = 0
    http_status = None
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            http_status = getattr(response, "status", None) or response.getcode()
            for raw in response:
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                body = line[5:].strip()
                if not body or body == "[DONE]":
                    continue
                event = json.loads(body)
                event_count += 1
                meta = event.get("meta_info") or {}
                now = time.perf_counter()
                if first_at is None and int(meta.get("completion_tokens") or 0) > 0:
                    first_at, first_meta = now, meta
                final_at, final_meta, final_event = now, meta, event
    except urllib.error.HTTPError as exc:
        detail = exc.read(2048).decode("utf-8", "replace")
        return {"error": "ENGINE:HTTP_%s:%s" % (exc.code, detail)}
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        return {"error": "INFRA:%r" % (exc,)}
    except (ValueError, json.JSONDecodeError) as exc:
        return {"error": "ENGINE:bad_stream:%r" % (exc,)}
    finish_reason = None
    if final_event:
        finish_reason = final_event.get("finish_reason")
    if finish_reason is None and final_meta:
        finish_reason = final_meta.get("finish_reason")
    stream_diagnostics = {
        "http_status": http_status,
        "sse_event_count": event_count,
        "finish_reason": finish_reason,
    }
    if first_at is None or not first_meta or not final_meta:
        return {
            "error": "ENGINE:no_token_event",
            "no_token_reason": classify_no_token_finish_reason(finish_reason),
            **stream_diagnostics,
        }
    def meta_int(meta, key):
        value = meta.get(key)
        return None if value is None else int(value)

    output_tokens = meta_int(final_meta, "completion_tokens")
    client_ttft = first_at - started
    timing = extract_server_timing(first_meta, final_meta)
    server_ttft = timing["server_ttft_s"]
    return {
        "ttft_s": server_ttft if server_ttft is not None else client_ttft,
        "ttft_source": "server" if server_ttft is not None else "client_proxy",
        "ttft_client_s": client_ttft,
        "prompt_tokens": meta_int(first_meta, "prompt_tokens"),
        "cached_tokens": meta_int(first_meta, "cached_tokens"),
        "output_tokens": output_tokens,
        "tpot_s": ((final_at - first_at) / (output_tokens - 1))
        if final_at is not None and output_tokens is not None and output_tokens > 1 else None,
        "error": None,
        **stream_diagnostics,
        **timing,
    }


def flush_engine_cache(timeout=30.0, retries=8, retry_sleep_s=5.0):
    """Flush KV/prefix state while preserving compiled code caches.

    Shape warmup deliberately skips replay gaps. Retaining every completed
    chain's prefix until the end can therefore create a cache-pressure burst
    that the formal replay never produces. Segmented warmup calls this only
    between complete chain waves, never while a request is in flight.
    """
    base = os.environ.get("S1_ENGINE_URL", "").rstrip("/")
    if not base:
        raise RuntimeError("INFRA:S1_ENGINE_URL is required")
    request = urllib.request.Request(
        base + "/flush_cache",
        data=b"{}",
        headers=_engine_headers({"Content-Type": "application/json"}),
        method="POST",
    )
    last_error = None
    for attempt in range(1, int(retries) + 1):
        try:
            with urllib.request.urlopen(request, timeout=float(timeout)) as response:
                status = getattr(response, "status", None) or response.getcode()
                if 200 <= int(status) < 300:
                    return
                last_error = RuntimeError("INFRA:flush_cache_http_%s" % status)
        except urllib.error.HTTPError as exc:
            last_error = RuntimeError("INFRA:flush_cache_http_%s" % exc.code)
            # SGLang returns 400 while scheduler requests are still draining.
            # This is transient at a wave boundary; retry without changing the
            # workload or issuing another generation request.
            if exc.code != 400:
                raise last_error from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            last_error = RuntimeError("INFRA:flush_cache:%r" % (exc,))
        if attempt < int(retries):
            time.sleep(float(retry_sleep_s))
    raise last_error


def write_json_atomic(path, value):
    """Publish one small producer ledger without exposing a partial JSON file."""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(value, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


TS_KEYS = ("t_recv_s", "t_admit_s", "t_exec_start_s", "t_first_token_s",
           "queue_time_s", "server_ttft_s", "ttft_client_s", "ttft_source")
ENGINE_DIAGNOSTIC_KEYS = ("http_status", "sse_event_count", "finish_reason",
                          "no_token_reason")

# --------------------------------------------------------------------------- #
# 回放节拍（pacing）
# --------------------------------------------------------------------------- #
PACING_REPLAY = "replay_gap"
PACING_SCALED = "chain-total-gap-scaled-v1"
PACING_FROZEN = "pressure-window-frozen-effective-gap-v1"
PACING_NONE = "none(smoke)"
GAP_ROUNDING = "last-nonzero-remainder"
PRESSURE_WINDOW_ROLES = ("anchor", "prelude", "score")

#: 客户端绝对时间戳（epoch 秒）。**无条件记录**：稳态 TPM 窗口依赖它，
#: 而服务端 t_recv_s 需要引擎开 --enable-metrics 才有（实测 coverage 常为 0）。
CLIENT_TS_KEYS = ("client_dispatch_at_s", "client_first_token_at_s", "client_finish_at_s")


def build_gap_plan(chains, rows, cap_ms):
    """按 chain 压缩累计 replay gap（不删任何请求、不改 chain 内顺序）。

        S = Σ replay_gap_ms
        S <= cap_ms : 逐请求 gap **原样不变**（字节级一致）
        S >  cap_ms : α = cap_ms / S，eff_i = round(orig_i × α)

    整数毫秒舍入，余量加到该 chain **最后一个非零 gap**，保证
        Σ eff == min(Σ orig, cap_ms)
    返回 (plan, stats)。plan[chain_id] = [effective_ms per request index]。
    """
    plan, affected = {}, []
    orig_total = eff_total = 0
    n_req_capped = 0
    for ch in chains:
        cid = ch["chain_id"]
        orig = [int(rows[rid].get("replay_gap_ms") or 0) for rid in ch["req_ids"]]
        S = sum(orig)
        orig_total += S
        if cap_ms <= 0 or S <= cap_ms:
            eff = list(orig)
        else:
            alpha = cap_ms / float(S)
            eff = [int(round(g * alpha)) for g in orig]
            last = max((i for i, g in enumerate(orig) if g > 0), default=None)
            if last is not None:
                eff[last] += cap_ms - sum(eff)
            affected.append({"chain_id": cid, "original_ms": S, "effective_ms": sum(eff),
                             "alpha": round(alpha, 6), "n_requests": len(orig)})
            n_req_capped += len(orig)
        plan[cid] = eff
        eff_total += sum(eff)
    affected.sort(key=lambda x: -x["original_ms"])
    stats = {
        "pacing_rule": "S=Σreplay_gap; α=min(1, cap/S); eff_i=round(orig_i×α)",
        "rounding": GAP_ROUNDING,
        "chain_gap_cap_ms": cap_ms,
        "n_chains": len(chains),
        "n_chains_compressed": len(affected),
        "n_requests_in_compressed_chains": n_req_capped,
        "original_gap_sum_ms": orig_total,
        "effective_gap_sum_ms": eff_total,
        "affected_chains": affected[:50],
        "affected_chains_truncated": max(0, len(affected) - 50),
    }
    return plan, stats


def pressure_window_plan(chains):
    """Validate and return an optional cohort-frozen pressure-window plan.

    A pressure-window cohort carries the effective timing selected from the
    full parent replay.  Re-scaling those gaps after slicing the cohort would
    silently define a different workload, so mixed/partial contracts are
    rejected instead of falling back to ``build_gap_plan``.
    """
    has_contract = [
        ("effective_replay_gap_ms" in ch or "pressure_window_role" in ch)
        for ch in chains
    ]
    if not any(has_contract):
        return None, None, None
    if not all(has_contract):
        raise ValueError("pressure-window cohort must provide timing fields on every chain")

    gaps, roles = {}, {}
    counts = collections.Counter()
    for ch in chains:
        cid, rids = ch["chain_id"], ch["req_ids"]
        eff = ch.get("effective_replay_gap_ms")
        role = ch.get("pressure_window_role")
        if not isinstance(eff, list) or len(eff) != len(rids):
            raise ValueError("chain %s effective_replay_gap_ms length != req_ids" % cid)
        if not isinstance(role, list) or len(role) != len(rids):
            raise ValueError("chain %s pressure_window_role length != req_ids" % cid)
        if any(not isinstance(x, int) or isinstance(x, bool) for x in eff):
            raise ValueError("chain %s has non-integer effective gap" % cid)
        eff = list(eff)
        if any(x < 0 for x in eff):
            raise ValueError("chain %s has negative effective gap" % cid)
        bad = [x for x in role if x not in PRESSURE_WINDOW_ROLES]
        if bad:
            raise ValueError("chain %s has invalid pressure-window role %r" % (cid, bad[0]))
        gaps[cid], roles[cid] = eff, list(role)
        counts.update(role)
    contract = {
        "kind": PACING_FROZEN,
        "source": "cohort.chains[].effective_replay_gap_ms",
        "scaling_recomputed": False,
        "roles": list(PRESSURE_WINDOW_ROLES),
        "role_counts": dict(counts),
        "n_chains": len(chains),
        "n_requests": sum(counts.values()),
        "effective_gap_sum_ms": sum(sum(x) for x in gaps.values()),
    }
    contract["sha256"] = hashlib.sha256(
        json.dumps({"gaps": sorted(gaps.items()), "roles": sorted(roles.items())},
                   ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]
    return gaps, roles, contract


def _tier(value, edges):
    value = int(value or 0)
    for i, edge in enumerate(edges):
        if value < edge:
            return i
    return len(edges)


def warmup_shape_key(row):
    """Logical request tiers; not proof of compiled kernel coverage."""
    idx = row.get("_idx_in_chain")
    if idx is None:
        idx = row.get("idx_in_chain")
    if idx == 0 or row.get("phase") == "context_reset":
        phase = "chain_start"
    elif row.get("phase") == "turn_start":
        phase = "turn_start"
    else:
        phase = "intra"
    prompt = int(row.get("glm_tokens") or 0)
    uncached_value = row.get("uncached_expected")
    uncached = int(prompt if uncached_value is None else uncached_value)
    output = int(row.get("max_output_i") or 512)
    return (
        phase,
        _tier(prompt, (32768, 65536, 131072, 192 * 1024, 224 * 1024, 240 * 1024, 262144)),
        _tier(uncached, (512, 2048, 8192, 32768, 65536, 131072)),
        _tier(output, (16, 128, 512, 2048, 8192)),
    )


def select_warmup_chains(chains, rows, minimum=1):
    """Deterministic greedy set cover over represented kernel regimes."""
    shapes_by_chain = []
    universe = set()
    for chain in chains:
        shapes = {warmup_shape_key(rows[rid]) for rid in chain["req_ids"] if rid in rows}
        shapes_by_chain.append(shapes)
        universe.update(shapes)
    uncovered, selected, remaining = set(universe), [], list(range(len(chains)))
    while uncovered and remaining:
        best = max(remaining, key=lambda i: (len(shapes_by_chain[i] & uncovered), -i))
        if not (shapes_by_chain[best] & uncovered):
            break
        selected.append(best)
        uncovered.difference_update(shapes_by_chain[best])
        remaining.remove(best)
    for i in remaining:
        if len(selected) >= min(max(1, minimum), len(chains)):
            break
        selected.append(i)
    return [chains[i] for i in selected], len(universe), len(uncovered)


def effective_warmup_coverage(chains, rows, output_cap):
    """Logical tiers only; never claim these enumerate compiled kernel keys."""
    original, effective = set(), set()
    capped = 0
    for chain in chains:
        for rid in chain["req_ids"]:
            if rid not in rows:
                continue
            row = rows[rid]
            original.add(warmup_shape_key(row))
            actual = dict(row)
            length = int(row.get("max_output_i") or 512)
            if output_cap and length > output_cap:
                actual["max_output_i"] = output_cap
                capped += 1
            effective.add(warmup_shape_key(actual))
    return {
        "coverage_basis": "logical_request_tiers_not_kernel_specializations",
        "original_shape_count": len(original),
        "effective_shape_count": len(effective),
        "original_shapes_not_exercised_after_output_cap": len(original - effective),
        "output_capped_request_count": capped,
        "kernel_specialization_coverage_verified": False,
    }


class Rec:
    __slots__ = ("row", "raw_id", "ctx", "ttft", "ptok", "cached", "otok",
                 "tpot", "err", "wall", "ts", "diagnostics", "scored",
                 "t_dispatch", "t_first", "t_finish", "eff_gap_ms")

    def __init__(self, row, ctx, scored=True):
        self.row, self.ctx, self.scored = row, ctx, scored
        self.raw_id = row.get("_req_id")
        self.ttft = self.ptok = self.cached = self.otok = self.tpot = self.wall = None
        self.ts = {}
        self.diagnostics = {}
        self.err = None
        self.t_dispatch = self.t_first = self.t_finish = None   # epoch 秒
        self.eff_gap_ms = None


def raw_record(r):
    """raw 的**唯一定义**：drive 增量落盘与收尾补写共用，避免两处形状漂移。"""
    row = r.row
    return {
        "req_id": row.get("_req_id"), "session_id": row["session_id"],
        "chain_id": row["chain_id"], "pack": row["pack"], "view": row["view"],
        "logical_call_id": row["logical_call_id"],
        "prefix_family_id": row.get("prefix_family_id"),
        "routing_key": row.get("sys_tools_hash"),
        "phase": row.get("phase"), "idx_in_chain": row.get("_idx_in_chain"),
        "phase_basis": row.get("phase_basis"), "head_kind": row.get("head_kind"),
        "prefix_carrier": row.get("prefix_carrier"),
        "edge_type": row.get("edge_type"),
        "glm_tokens": row.get("glm_tokens"),
        "ds_tokens": row.get("ds_tokens"),
        "uncached_expected": row.get("uncached_expected"),
        "max_output_i": row.get("max_output_i"),
        "replay_gap_ms": row.get("replay_gap_ms"),
        "effective_replay_gap_ms": r.eff_gap_ms,
        **({"pressure_window_role": r.ctx.get("pressure_window_role"),
            "pressure_window_timing_contract":
                r.ctx.get("pressure_window_timing_contract")}
           if r.ctx.get("pressure_window_role") is not None else {}),
        "sampling_weight": row.get("sampling_weight"),
        "cache_namespace": r.ctx["cache_namespace"],
        "ttft_s": r.ttft, "prompt_tokens": r.ptok, "cached_tokens": r.cached,
        "output_tokens": r.otok, "tpot_s": r.tpot, "wall_s": r.wall,
        # 客户端绝对时间戳（epoch 秒）——稳态 TPM 窗口依赖；无条件写
        "client_dispatch_at_s": r.t_dispatch,
        "client_first_token_at_s": r.t_first,
        "client_finish_at_s": r.t_finish,
        **(r.ts or {}),
        **(r.diagnostics or {}),
        "error_class": classify(r.err), "error": r.err,
    }


def drive(chain, rows, renderer, bodies, model, cache_ns, out, lock, stop,
          scored=True, skip_gap=False, gaps_ms=None, roles=None, timing_contract=None,
          raw_fh=None, on_done=None, max_output_override=None):
    for idx, rid in enumerate(chain["req_ids"]):
        if stop.is_set():
            return
        row = rows[rid]
        eff_gap = (int(gaps_ms[idx]) if gaps_ms is not None and idx < len(gaps_ms)
                   else int(row.get("replay_gap_ms") or 0))
        if not skip_gap:
            gap = eff_gap / 1000.0
            # 可中断等待：stop 被置位时立即退出，不再用 time.sleep 睡满整个 gap
            if gap > 0 and stop.wait(gap):
                return
        requested_max_output = int(row.get("max_output_i") or 512)
        effective_max_output = (
            min(requested_max_output, int(max_output_override))
            if max_output_override is not None else requested_max_output
        )
        ctx = {"req_id": rid, "session_id": row["session_id"],
               "prefix_family_id": row.get("prefix_family_id"),
               "cache_namespace": cache_ns, "routing_key": row.get("sys_tools_hash"),
               "model": model, "max_output_i": effective_max_output,
               "phase": row.get("phase"), "scored": scored,
               "pressure_window_role": (roles[idx] if roles is not None else None),
               "pressure_window_timing_contract": timing_contract}
        rec = Rec(row, ctx, scored)
        rec.eff_gap_ms = None if skip_gap else eff_gap
        prompt, b = None, bodies.get(rid)
        if b is None:
            rec.err = ERR_HARNESS_DATA + ":body_missing"      # 不算服务错误
        else:
            try:
                prompt = renderer.render(b)
            except Exception as e:
                rec.err = ERR_HARNESS_RENDER + ":%r" % (e,)
        if prompt is not None:
            t0 = time.time()
            rec.t_dispatch = t0
            try:
                o = call_engine(ctx, prompt, ctx["max_output_i"])
                _ct = o.get("ttft_client_s")
                rec.t_first = (t0 + float(_ct)) if _ct is not None else None
                rec.ttft, rec.ptok = o.get("ttft_s"), o.get("prompt_tokens")
                rec.cached, rec.otok = o.get("cached_tokens"), o.get("output_tokens")
                rec.tpot, rec.err = o.get("tpot_s"), o.get("error")
                rec.ts = {k: o.get(k) for k in TS_KEYS}
                rec.diagnostics = {k: o.get(k) for k in ENGINE_DIAGNOSTIC_KEYS
                                   if o.get(k) is not None}
            except NotImplementedError:
                raise
            except Exception as e:
                # 若异常消息本身已带四类前缀（如 call_engine 抛 RuntimeError("INFRA:...")），
                # 必须**原样保留**。否则 repr() 会把它包成 RuntimeError('INFRA:...')，
                # classify() 的前缀匹配失效 -> 配置缺失（如 S1_ENGINE_URL 未设）
                # 会被误记为 ENGINE 服务错误，表现为"引擎大量报错"。
                _m = str(e)
                rec.err = _m if _m.startswith(("INFRA", "HARNESS_DATA", "HARNESS_RENDER")) \
                    else "%r" % (e,)
            rec.wall = time.time() - t0
            rec.t_finish = t0 + rec.wall
        with lock:
            out.append(rec)
            if raw_fh is not None:                 # 增量落盘：每请求 append+flush
                raw_fh.write(json.dumps(raw_record(rec), ensure_ascii=False) + "\n")
                raw_fh.flush()
            if on_done is not None:
                on_done(rec)


def build_renderer(args):
    """按 ``--renderer`` 选渲染路径。

    ``jinja``（默认）—— GLM 那套：HF ``apply_chat_template`` + ``chat_template.jinja``。
                        不传该参数时行为与历史完全一致。

    ``ds``            —— DeepSeek V4.1 那套：模型**没有 Jinja 模板**，模板逻辑在自带的
                        ``encoding/encoding.py`` 里，入口 ``encode_messages(messages,
                        thinking_mode=...)`` 直接返回最终 prompt，且 tools 要挂在第一条
                        system 消息上。见 ``g0a/ds_renderer.py``。
    """
    if getattr(args, "renderer", "jinja") != "ds":
        return Renderer(args.tok_dir)
    import importlib.util
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "g0a", "ds_renderer.py")
    if not os.path.exists(p):
        raise RuntimeError("INFRA:ds_renderer_missing:%s" % p)
    spec = importlib.util.spec_from_file_location("ds_renderer", p)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["ds_renderer"] = mod
    spec.loader.exec_module(mod)
    return mod.DSRenderer(tok_dir=args.tok_dir,
                          encoding_dir=(args.encoder_dir or None),
                          tool_result_policy=args.tool_result_policy)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="数据集根目录")
    ap.add_argument("--tok-dir", default="./glm_tok")
    ap.add_argument("--renderer", default="jinja", choices=("jinja", "ds"),
                    help="jinja=GLM 的 chat_template.jinja（默认，行为不变）；"
                         "ds=DeepSeek V4.1 自带的 encoding/encoding.py（没有 Jinja 模板）")
    ap.add_argument("--encoder-dir", default="",
                    help="--renderer ds 时的 encoder 目录（默认 <tok-dir>/encoding）")
    ap.add_argument("--tool-result-policy", default="all", choices=("last", "all"),
                    help="仅 --renderer ds：一条消息带多个 tool-result 时全留（all）还是只留最后一个（last）")
    ap.add_argument("--set", default="sensitivity-500")
    ap.add_argument("--n", type=int, default=1, help="并发 Agent 槽位数（只改槽数，不改样本集合）")
    ap.add_argument("--model", default="glm-5.3-flash")
    ap.add_argument("--seed", type=int, default=20260910)
    ap.add_argument("--instance-id", default="", help="本档所用推理实例（每档应独立）")
    ap.add_argument("--cache-namespace", default="")
    ap.add_argument("--out-dir", default="./eval_out")
    ap.add_argument("--cohort-file", default="")
    ap.add_argument("--freeze-cohort", action="store_true")
    ap.add_argument("--self-check", action="store_true", help="只验证 payload 重建，不施压")
    ap.add_argument("--warmup", action="store_true",
                    help="只做本档 shape-aware JIT warmup（跳过 replay_gap、不计分）")
    ap.add_argument("--warmup-min-chains", type=int, default=16,
                    help="warmup 至少覆盖多少条链（**与并发 N 解耦**：由形状覆盖需求决定，"
                         "不由槽位数决定）")
    ap.add_argument("--warmup-mode", choices=("shape", "full"), default="shape",
                    help="shape=每个 kernel regime 取确定性最小覆盖；full=完整 cohort")
    ap.add_argument("--warmup-flush-every-chains", type=int, default=0,
                    help="每完成 K 条完整 warmup chain 后清 KV/prefix cache（保留 code cache）；"
                         "0=不分段。用于避免跳过 replay_gap 后把跨链缓存压力误当作正式负载")
    ap.add_argument("--warmup-max-output-tokens", type=int, default=0,
                    help="warmup 每请求最多生成多少 token；完整 prompt/prefix 仍原样处理。"
                         "0=不限制。仅影响 warmup，不改变正式回放")
    ap.add_argument("--prefix-warm-from-excluded", action="store_true",
                    help="把链内被排除的前驱请求**不计分**地喂一遍，使缓存状态与原始链一致"
                         "（默认关闭：会多打约 5.7%% 请求量）")
    ap.add_argument("--include-all", action="store_true", help="诊断用，结论不可用")
    ap.add_argument("--no-body-cache", action="store_true")
    ap.add_argument("--max-chains", type=int, default=0,
                    help="只用 cohort 的前 K 条链（**冒烟/管线验证用**，正式测量不要设）")
    ap.add_argument("--chain-gap-cap-s", type=float, default=3600.0,
                    help="按 chain 压缩累计 replay gap 的上限（秒），**默认 3600 生效**"
                         "（正式口径）。S<=cap 的 chain 逐请求 gap 原样不变；"
                         "传 0 恢复旧口径 replay_gap（仅用于与旧结果对照）")
    ap.add_argument("--pacing", default="auto",
                    choices=["auto", "replay_gap", "chain-total-gap-scaled-v1", "none"],
                    help="回放节拍。auto：给了 cap 就用 chain-total-gap-scaled-v1，否则 replay_gap")
    ap.add_argument("--checkpoint-every", type=int, default=25,
                    help="每完成多少请求写一次 checkpoint（0=关闭）")
    ap.add_argument("--auth-preflight-output", default="",
                    help="首个正式请求前写 exact-workload 鉴权探针；失败则不开始回放")
    ap.add_argument("--no-gap", action="store_true",
                    help="跳过 replay_gap（**冒烟用**，会记录 pacing=none(smoke)，结论不可用）")
    args = ap.parse_args()
    if args.warmup_flush_every_chains < 0:
        ap.error("--warmup-flush-every-chains must be >= 0")
    if args.warmup_max_output_tokens < 0:
        ap.error("--warmup-max-output-tokens must be >= 0")

    # ---- 回放节拍：**参数校验必须早于数据加载**，否则错参数要等到读盘后才报 ----
    if args.no_gap:
        pacing = PACING_NONE
    elif args.pacing == "auto":
        pacing = PACING_SCALED if args.chain_gap_cap_s > 0 else PACING_REPLAY
    else:
        pacing = args.pacing
    if pacing == PACING_SCALED and args.chain_gap_cap_s <= 0:
        ap.error("--pacing %s 需要 --chain-gap-cap-s > 0" % PACING_SCALED)
    if pacing == PACING_NONE and not args.no_gap:
        ap.error('--pacing "none" 仅由 --no-gap 使用（结论不可用于容量判断）')
    cap_ms = int(round(args.chain_gap_cap_s * 1000)) if pacing == PACING_SCALED else 0

    rows, _ch, _grp = load_index(args.root, args.include_all)
    os.makedirs(args.out_dir, exist_ok=True)
    acct = serving_accounting(args.root)
    cpath = args.cohort_file or os.path.join(args.out_dir,
                                             "cohort_%s_seed%d.json" % (args.set, args.seed))
    coh = freeze_cohort(args.root, args.set, rows, args.seed, cpath,
                        force=args.freeze_cohort, accounting=acct)
    if args.freeze_cohort:
        print("cohort 已冻结：%s（sha=%s）" % (cpath, coh["cohort_sha256"]))
        print(json.dumps(acct, ensure_ascii=False, indent=2))
        return 0
    want = [q for x in coh["chains"] for q in x["req_ids"]]
    print("[cohort] %s：%d 链 / %d 请求，sha=%s"
          % (args.set, len(coh["chains"]), len(want), coh["cohort_sha256"]), file=sys.stderr)
    if coh.get("serving_load_filter"):
        f = coh["serving_load_filter"]
        print("[cohort] ⚠ 声明 %d 链/%d 请求 → 实可跑 %d 链/%d 请求"
              % (f["declared_chains"], f["declared_requests"],
                 f["usable_chains"], f["usable_requests"]), file=sys.stderr)

    cache = os.path.join(args.out_dir, "body_cache_%s.jsonl" % args.set)
    bodies = ensure_bodies(args.root, want, cache, use_cache=not args.no_body_cache)
    renderer_started = time.time()
    print("[renderer] 加载 tokenizer/render contract：%s" % args.tok_dir,
          file=sys.stderr, flush=True)
    renderer = build_renderer(args)
    print("[renderer] 就绪，耗时 %.1fs" % (time.time() - renderer_started),
          file=sys.stderr, flush=True)

    if args.self_check:
        bad = 0
        for rid in want:
            b = bodies.get(rid)
            if b is None:
                continue
            n = renderer.n_tokens(renderer.render(b))
            if n != rows[rid].get("glm_tokens"):
                bad += 1
                if bad <= 5:
                    print("  失配 %s: 重建=%d 记录=%d" % (rid, n, rows[rid].get("glm_tokens")))
        print("自检结果：失配=%d ；共=%d" % (bad, len(want)))
        print("SELF_CHECK: %s" % ("PASS" if bad == 0 else "FAIL"))
        return 0 if bad == 0 else 1

    chains = coh["chains"][:args.max_chains] if args.max_chains else coh["chains"]
    if args.max_chains or args.no_gap:
        print("[smoke] max_chains=%s no_gap=%s —— 结论不可用于任何容量判断"
              % (args.max_chains or "all", args.no_gap), file=sys.stderr)
    # ---- gap 计划（需要 chains/rows，故在数据加载之后）----
    # pressure-window 是从完整回放中截取的连续压力窗口；它的 effective
    # gap 是 cohort 身份的一部分，不得对缩小后的 chain 再做 cap/scaling。
    frozen_gaps, pressure_roles, pressure_contract = pressure_window_plan(chains)
    if pressure_contract:
        if args.no_gap:
            ap.error("pressure-window cohort 禁止 --no-gap；必须使用冻结 effective gap")
        pacing, cap_ms = PACING_FROZEN, None
        gap_plan = frozen_gaps
        gap_stats = {
            "pacing_rule": "use cohort-frozen effective_replay_gap_ms verbatim",
            "rounding": None, "chain_gap_cap_ms": None,
            "n_chains": len(chains), "n_chains_compressed": None,
            "n_requests_in_compressed_chains": None,
            "original_gap_sum_ms": None,
            "effective_gap_sum_ms": pressure_contract["effective_gap_sum_ms"],
            "affected_chains": [], "affected_chains_truncated": 0,
            "pressure_window_timing_contract": pressure_contract,
        }
    else:
        gap_plan, gap_stats = build_gap_plan(chains, rows, cap_ms)
    _wl = {"pacing": pacing, "chain_gap_cap_ms": cap_ms,
           "rounding": None if pressure_contract else GAP_ROUNDING,
           "cohort_sha256": coh["cohort_sha256"],
           "eff_gap_sum_by_chain": sorted((cid, sum(v)) for cid, v in gap_plan.items())}
    if pressure_contract:
        _wl["pressure_window_timing_contract_sha256"] = pressure_contract["sha256"]
    workload_hash = hashlib.sha256(
        json.dumps(_wl, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]
    if pressure_contract:
        print("[pacing] %s | cohort-frozen | %d chains / %d requests | Σgap %.1fh | contract=%s"
              % (pacing, pressure_contract["n_chains"], pressure_contract["n_requests"],
                 pressure_contract["effective_gap_sum_ms"] / 3.6e6,
                 pressure_contract["sha256"]), file=sys.stderr)
    else:
        print("[pacing] %s | cap=%s | 压缩 %d/%d 条 chain（影响 %d 请求）| Σgap %.1fh → %.1fh"
              % (pacing, ("%ds" % args.chain_gap_cap_s) if cap_ms else "off",
                 gap_stats["n_chains_compressed"], gap_stats["n_chains"],
                 gap_stats["n_requests_in_compressed_chains"],
                 gap_stats["original_gap_sum_ms"] / 3.6e6,
                 gap_stats["effective_gap_sum_ms"] / 3.6e6), file=sys.stderr)
    if cap_ms:
        print("           ↑ 尾部长链只压缩等待时间，**不删除任何请求**；"
              "workload_hash=%s" % workload_hash, file=sys.stderr)

    pick = min(args.n, len(chains))
    cache_ns = args.cache_namespace or hashlib.sha256(
        ("%s|%s|N%s|%s" % (args.model, args.set, args.n, args.seed)).encode()).hexdigest()[:12]
    cfg = {"set": args.set, "N": args.n, "model": args.model, "seed": args.seed,
           "instance_id": args.instance_id or None, "cache_namespace": cache_ns,
           "cohort_sha256": coh["cohort_sha256"], "cohort_version": coh["cohort_version"],
           "warmup": args.warmup, "prefix_warm_from_excluded": args.prefix_warm_from_excluded,
           "cohort_file": cpath,
           "pacing": pacing,
           "chain_gap_cap_ms": cap_ms,
           "gap_rounding": None if pressure_contract else GAP_ROUNDING,
           "workload_hash": workload_hash,
           "cohort_sha256_canonical": coh.get("cohort_sha256_canonical"),
           "max_chains": args.max_chains or None}
    if pressure_contract:
        cfg["pressure_window_timing_contract"] = pressure_contract
    cfg["config_hash"] = hashlib.sha256(
        json.dumps(cfg, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]

    auth_probe = None
    if args.auth_preflight_output:
        if s1_auth_preflight is None:
            raise RuntimeError("INFRA:auth_preflight_module_missing")
        auth_probe = s1_auth_preflight.run_probe(
            os.environ.get("S1_ENGINE_URL", ""),
            os.environ.get("S1_ENGINE_AUTH_TOKEN"),
            "%s-auth-preflight" % (args.instance_id or "s1-loadgen"),
            session_id="auth-preflight",
            cache_namespace=cache_ns + "-auth-preflight",
            routing_key="auth-preflight",
        )
        write_json_atomic(args.auth_preflight_output, auth_probe)
        if not auth_probe.get("ok"):
            print("[auth] exact-workload preflight failed before dispatch",
                  file=sys.stderr, flush=True)
            return 43

    # ---- warmup 模式：跳过 replay_gap、不计分 ----
    if args.warmup:
        out, lock, stop = [], threading.Lock(), threading.Event()
        if args.warmup_mode == "shape":
            print("[warmup] 计算 shape 覆盖与最小链集合", file=sys.stderr, flush=True)
            warm_chains, shape_count, missing_shapes = select_warmup_chains(
                chains, rows, minimum=max(1, args.warmup_min_chains))
        else:
            warm_chains, shape_count, missing_shapes = chains, len({
                warmup_shape_key(rows[rid]) for ch in chains for rid in ch["req_ids"]
                if rid in rows}), 0
        wave_size = args.warmup_flush_every_chains or len(warm_chains)
        print("[warmup] 已选 %d/%d 条链、%d 个请求、%d shapes；wave=%d、workers=%d"
              % (len(warm_chains), len(chains),
                 sum(len(ch["req_ids"]) for ch in warm_chains), shape_count,
                 wave_size, min(pick, wave_size)),
              file=sys.stderr, flush=True)
        if args.warmup_max_output_tokens:
            print("[warmup] 输出上限=%d tokens/request（prompt/prefix 保持完整）"
                  % args.warmup_max_output_tokens, file=sys.stderr, flush=True)
        expected = sum(len(ch["req_ids"]) for ch in warm_chains)
        effective_coverage = effective_warmup_coverage(
            warm_chains, rows, args.warmup_max_output_tokens)
        progress_path = os.path.join(args.out_dir, "warmup_progress.json")
        flush_count = 0
        completed_chain_count = 0
        current_wave_index = 0
        total_wave_count = (len(warm_chains) + wave_size - 1) // wave_size

        def write_warmup_progress(stage, latest_req_id=None):
            attempted = len(out)
            write_json_atomic(progress_path, {
                "stage": stage,
                "expected_request_count": expected,
                "attempted_request_count": attempted,
                "successful_request_count": sum(1 for r in out if r.err is None),
                "request_error_count": sum(1 for r in out if r.err is not None),
                "selected_chain_count": len(warm_chains),
                "completed_chain_count": completed_chain_count,
                "shape_count": shape_count,
                "missing_shape_count": missing_shapes,
                "current_wave_index": current_wave_index,
                "total_wave_count": total_wave_count,
                "flush_every_chains": args.warmup_flush_every_chains,
                "flush_count": flush_count,
                "max_output_tokens_cap": args.warmup_max_output_tokens or None,
                "latest_req_id": latest_req_id,
                "updated_at_s": time.time(),
            })

        def on_warmup_done(rec):
            if len(out) % 25 == 0 or rec.err is not None:
                write_warmup_progress("running", rec.raw_id)

        write_warmup_progress("starting")
        for wave_start in range(0, len(warm_chains), wave_size):
            current_wave_index = wave_start // wave_size + 1
            write_warmup_progress("running")
            wave = warm_chains[wave_start:wave_start + wave_size]
            q = collections.deque(wave)
            ql = threading.Lock()

            def w():
                while True:
                    with ql:
                        if not q or stop.is_set():
                            return
                        ch = q.popleft()
                    drive(ch, rows, renderer, bodies, args.model, cache_ns + "-warmup",
                          out, lock, stop, scored=False, skip_gap=True,
                          roles=(pressure_roles or {}).get(ch["chain_id"]),
                          timing_contract=(pressure_contract or {}).get("sha256"),
                          max_output_override=(args.warmup_max_output_tokens or None),
                          on_done=on_warmup_done)

            before = len(out)
            ts = [threading.Thread(target=w, daemon=True)
                  for _ in range(min(pick, len(wave)))]
            for t in ts:
                t.start()
            for t in ts:
                t.join()
            completed_chain_count += len(wave)
            wave_errors = sum(1 for r in out[before:] if r.err is not None)
            if wave_errors:
                break
            if wave_start + len(wave) < len(warm_chains):
                flush_engine_cache()
                flush_count += 1
                write_warmup_progress("running")
                print("[warmup] wave %d/%d 完成，已清 KV/prefix cache（保留 code cache）"
                      % (wave_start // wave_size + 1,
                         (len(warm_chains) + wave_size - 1) // wave_size),
                      file=sys.stderr)

        ok = sum(1 for r in out if r.err is None)
        errors = len(out) - ok
        summary = {
            "effective_coverage": effective_coverage,
            "expected_request_count": expected,
            "attempted_request_count": len(out),
            "successful_request_count": ok,
            "request_error_count": errors,
            "selected_chain_count": len(warm_chains),
            "completed_chain_count": completed_chain_count,
            "shape_count": shape_count,
            "missing_shape_count": missing_shapes,
            "current_wave_index": current_wave_index,
            "total_wave_count": total_wave_count,
            "flush_every_chains": args.warmup_flush_every_chains,
            "flush_count": flush_count,
            "max_output_tokens_cap": args.warmup_max_output_tokens or None,
        }
        os.makedirs(args.out_dir, exist_ok=True)
        summary_path = os.path.join(args.out_dir, "warmup_summary.json")
        with open(summary_path, "w", encoding="utf-8") as fh:
            json.dump(summary, fh, ensure_ascii=False, indent=2)
        write_warmup_progress("complete" if not errors and len(out) == expected
                              and not missing_shapes else "failed")
        print("[warmup] N=%d mode=%s 选择 %d/%d 条链，成功 %d/%d 个请求、错误=%d、"
              "%d 个 shape，遗漏=%d"
              "（跳过 gap、不计分）"
              % (args.n, args.warmup_mode, len(warm_chains), len(chains), ok,
                 expected, errors, shape_count, missing_shapes))
        print("[warmup] summary %s" % summary_path)
        if len(out) != expected or errors or missing_shapes:
            print("[warmup] FAILED: 请求账或 shape 覆盖未闭合", file=sys.stderr)
            return 1
        print("[warmup] ★下一步：清 KV / prefix cache（保留 code cache），"
              "再用同一 N 与同一 cohort 跑正式回放。")
        return 0

    # ---- 正式压测 ----
    results, lock, stop = [], threading.Lock(), threading.Event()
    ts = int(time.time())
    raw_p = os.path.join(args.out_dir, "raw_%s_N%d_%s.jsonl" % (args.set, args.n, ts))
    run_p = os.path.join(args.out_dir, "run_%s_N%d_%s.json" % (args.set, args.n, ts))
    ckpt_p = os.path.join(args.out_dir, "checkpoint_%s_N%d_%s.json" % (args.set, args.n, ts))
    _ck = {"done": 0}

    def _on_done(rec):
        _ck["done"] += 1
        if args.checkpoint_every and _ck["done"] % args.checkpoint_every == 0:
            tmp = ckpt_p + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"n_done": _ck["done"], "n_attempted": len(results),
                           "raw_file": os.path.basename(raw_p), "at_s": time.time()},
                          f, ensure_ascii=False)
            os.replace(tmp, ckpt_p)
        if isinstance(rec.err, str) and rec.err.startswith((
                "ENGINE:HTTP_401:", "ENGINE:HTTP_403:")):
            stop.set()

    raw_fh = open(raw_p, "w", encoding="utf-8")
    # ``N`` is the number of concurrent Agent slots, not the number of chains.
    # Every N point must replay the same frozen cohort.
    queue = collections.deque(chains)
    ql = threading.Lock()
    t0 = time.time()
    if auth_probe is not None:
        auth_probe["measurement_started_at_s"] = t0
        auth_probe["probe_to_measurement_gap_s"] = (
            t0 - float(auth_probe["probe_completed_at_s"])
        )
        max_gap = float(auth_probe["max_probe_to_measurement_gap_s"])
        auth_probe["ok"] = bool(
            auth_probe.get("ok")
            and 0 <= auth_probe["probe_to_measurement_gap_s"] <= max_gap
        )
        write_json_atomic(args.auth_preflight_output, auth_probe)
        if not auth_probe["ok"]:
            raw_fh.close()
            print("[auth] probe-to-measurement gap exceeded fail-closed bound",
                  file=sys.stderr, flush=True)
            return 43

    def worker():
        while True:
            with ql:
                if not queue or stop.is_set():
                    return
                ch = queue.popleft()
            drive(ch, rows, renderer, bodies, args.model, cache_ns, results, lock, stop,
                  skip_gap=args.no_gap, gaps_ms=gap_plan.get(ch["chain_id"]),
                  roles=(pressure_roles or {}).get(ch["chain_id"]),
                  timing_contract=(pressure_contract or {}).get("sha256"),
                  raw_fh=raw_fh, on_done=_on_done)

    ths = [threading.Thread(target=worker, daemon=True) for _ in range(pick)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    wall = time.time() - t0
    raw_fh.close()

    # raw 已在 drive 内逐请求 append+flush（容错）；此处只做条数校验，**不得重复写**
    n_raw = sum(1 for _ in open(raw_p, encoding="utf-8"))
    if n_raw != len(results):
        print("[warn] raw 行数 %d != 结果数 %d（可能有请求在落盘前异常退出）"
              % (n_raw, len(results)), file=sys.stderr)
    json.dump({"config": cfg, "wall_s": wall, "n_attempted": len(results),
               "raw_file": os.path.basename(raw_p),
               "dispatched": sum(1 for r in results
                                 if classify(r.err) not in (ERR_HARNESS_DATA,
                                                            ERR_HARNESS_RENDER)),
               # ---- 回放节拍与时间轴压缩（正式 workload 身份的一部分）----
               "pacing": pacing,
               "chain_gap_cap_ms": cap_ms,
               "gap_rounding": None if pressure_contract else GAP_ROUNDING,
               "workload_hash": workload_hash,
               "gap_compression": gap_stats,
               **({"pressure_window_timing_contract": pressure_contract}
                  if pressure_contract else {}),
               "client_ts_keys": list(CLIENT_TS_KEYS),
               "steady_window_hint": {"start_min": 10, "len_min": 60,
                                      "denominator_minutes": 60},
               "abort_reason": (
                   "runtime_auth_rejected"
                   if any(isinstance(r.err, str) and r.err.startswith((
                       "ENGINE:HTTP_401:", "ENGINE:HTTP_403:")) for r in results)
                   else None
               )},
              open(run_p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print("原始量  %s\n运行信息 %s" % (raw_p, run_p))
    print("下一步：python3 s1_score.py --raw %s --run %s" % (raw_p, run_p))
    if any(isinstance(r.err, str) and r.err.startswith((
            "ENGINE:HTTP_401:", "ENGINE:HTTP_403:")) for r in results):
        print("[auth] runtime rejection detected; aborted remaining workload",
              file=sys.stderr, flush=True)
        return 44
    return 0


if __name__ == "__main__":
    sys.exit(main())
