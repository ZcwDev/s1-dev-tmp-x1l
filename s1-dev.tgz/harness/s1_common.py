#!/usr/bin/env python3
"""S1-Real-v2 压测/评测 公共层。

被 s1_loadgen.py（压测）与 s1_score.py（评测）共用，避免两边口径漂移。
**cohort 冻结逻辑与冻结常数在此唯一实现** —— 改动会改变 cohort SHA，必须同步评审侧。
"""
from __future__ import annotations

import collections
import gzip
import hashlib
import json
import os
import random
import sys

# --------------------------------------------------------------------------- #
# 冻结常数（勿改；改动会使结果与既有口径不可比）
# --------------------------------------------------------------------------- #
BUDGET_BASE_S = 0.5
BUDGET_RATE = 7000.0
ATTAINMENT_MIN = 0.95          # 仅供参考；budget_attainment 现为诊断项，不作硬门
BUDGET_TRIPWIRE = 0.80         # 低于此值要求解释，不否决
P95_INTRA_S = 3.0              # phase_gate() 的 intra 分类哨兵；也是 fast-intra 门限
P95_OVERALL_INTRA_S = 5.0
FAST_INTRA_UNCACHED_MAX = 4096
P95_TURN_START_S = 15.0
P95_CHAIN_START_S = 30.0
ERROR_RATE_MAX = 0.01
OCCUPANCY_MIX = {"biomaster": 0.796, "scimaster": 0.204}
SAMPLE_DIRECT = {"sensitivity-500"}     # 自带 req_ids
COHORT_VERSION = "dev-roster-v1"

#: 硬门 —— **两个通道相同**。budget_attainment 不在其中（见方案 §SLO）。
#: fast 使用数据侧冻结的 uncached_expected，不得改用部署实测 cache miss。
FAST_INTRA_GATE = "fast_intra(uncached_expected<=4096,<=3s)"
OVERALL_INTRA_GATE = "overall_intra(<=5s)"
TURN_START_GATE = "turn_start(<=15s)"
CHAIN_START_GATE = "chain_start(<=30s)"

#: R3 = **次级 workflow（新一轮对话）内部**的 intra。**可选门**：只有当数据集/运行里
#: 能推出 `intra_role` 时才加进硬门，所以 S1-Real-v2 已发布集的行为逐字节不变。
#:
#: 为什么单列：`overall_intra` 池化了三个 uncached 量级完全不同的子群体（实测总体）——
#:   R1 = 每条 workflow 的第 2 条   n=992    unc p95 45,909
#:   R2 = 同一 workflow 更深的 intra n=14,674 unc p95 24,047
#:   R3 = 次级 workflow 内的 intra   n=1,277  unc p95 300,482（占 7.5% 条数、43% unc 体量）
#: 混合 p95 = 42,321，**高于 R2 的 24,047**——超过 p95 的 847 条里约 830 条来自 R3。
#: 所以池化 p95 的值由评测集的**角色混合比例**决定，不由采样量决定：R3 占比 0% 的集读到
#: ~24K，7.5% 的集读到 ~42K（1.76 倍）。分层报数才可比。
#:
#: 门限 15s 是**按角色/预算**定的，不是顺延 intra 的 5s（2026-09-30 部署线裁定）：
#:   ① 语义：它是「一次新回合里的后续步骤」，用户在等整个回合，首调已给 15s，
#:      后续段没有理由更严；
#:   ② 可达性：5s 带落在 R3 的 p95 uncached 300,482 上要求 ~60K tok/s 的并发聚合预填，
#:      逼近单机单请求上限 74K——不可达的门不是门；
#:   ③ 不双重计分：R3 与 turn_start 同速（11.5K vs 10.0K tok/s）、吃同一份调度预算，
#:      两者定不同门限会在优化目标的账上重复计分。
P95_R3_INTRA_S = 15.0
R3_INTRA_GATE = "r3_intra(次级workflow内,<=15s)"

GATES = ("coverage=100%", "harness_data==0", "harness_render==0",
         "engine_error<1%", "infra_error<1%",
         FAST_INTRA_GATE, OVERALL_INTRA_GATE, TURN_START_GATE, CHAIN_START_GATE,
         "gated_phases_have_samples")

# selector 用于 scorer 选择请求；limit 是对应硬门秒数。
TTFT_GATE_SPECS = ((FAST_INTRA_GATE, "fast_intra", P95_INTRA_S),
                   (OVERALL_INTRA_GATE, "overall_intra", P95_OVERALL_INTRA_S),
                   (TURN_START_GATE, "turn_start", P95_TURN_START_S),
                   (CHAIN_START_GATE, "chain_start", P95_CHAIN_START_S))

R3_INTRA_SPEC = (R3_INTRA_GATE, "r3_intra", P95_R3_INTRA_S)


def stamp_intra_roles(rows):
    """就地给 intra 行打 `intra_role` ∈ {R1, R2, R3, R3_unknown}。

    角色从**本次运行自己**的链首行推（同 `chain_id` 且 `idx_in_chain`/`_idx_in_chain` 为 0），
    所以对已经跑过的运行也生效——不需要数据集重新导出。

    只在数据集显式声明了 phase（`phase_basis == "dataset"`）或链首就叫 turn_start 时才有意义；
    其它集不会被打标记，R3 门自然不进硬门清单，S1-Real-v2 已发布集不受影响。

    链首不在本次运行里的链（采样把链首丢了），其 intra 行标 `R3_unknown`，
    **不并入 R3**（避免高估），由 `intra_role_warnings` 计数暴露。
    """
    heads = {}
    for r in rows:
        idx = r.get("_idx_in_chain")
        if idx is None:
            idx = r.get("idx_in_chain")
        if idx == 0 and r.get("chain_id") is not None:
            heads[r["chain_id"]] = r
    n_unknown = 0
    for r in rows:
        if r.get("phase") != "intra":
            continue
        idx = r.get("_idx_in_chain")
        if idx is None:
            idx = r.get("idx_in_chain")
        head = heads.get(r.get("chain_id"))
        if head is None:
            r["intra_role"] = "R3_unknown"
            n_unknown += 1
        elif _is_secondary_head(head):
            r["intra_role"] = "R3"
        else:
            r["intra_role"] = "R1" if idx == 1 else "R2"
    return n_unknown


def _is_secondary_head(row):
    if row.get("head_kind") == "secondary_workflow":
        return True
    if row.get("phase_basis") == "dataset" and row.get("phase") == "turn_start":
        return True
    return row.get("phase") == "turn_start"


def ttft_gate_specs(rows):
    """本次运行的硬门清单。带 `intra_role == "R3"` 的样本时追加 R3 可选门。"""
    specs = list(TTFT_GATE_SPECS)
    if any(r.get("intra_role") == "R3" for r in rows):
        specs.append(R3_INTRA_SPEC)
    return tuple(specs)

# 保留基础相位映射供构造器/旧分析工具使用；它不再等同于完整硬门清单。
PHASE_GATE_LIMITS = (("intra", P95_INTRA_S),
                     ("turn_start", P95_TURN_START_S),
                     ("chain_start", P95_CHAIN_START_S))

ERR_HARNESS_DATA = "HARNESS_DATA"
ERR_HARNESS_RENDER = "HARNESS_RENDER"
ERR_ENGINE = "ENGINE"
ERR_INFRA = "INFRA"

#: TPM 族：显示名 -> 机器键（报告按显示名渲染）
TPM_LABELS = {
    "TPM(ALL)": "all",
    "TPM(input)": "input",
    "TPM(uncached-input)": "uncached_input_actual",
    "TPM(device-work)": "device_work",
    "TPM(decode)": "decode",
    "TPM(expected-uncached-input)": "expected_uncached_input",
}
TPM_FORMULAS = {
    "TPM(ALL)": "(Σ prompt_tokens + Σ output_tokens) / wall_min",
    "TPM(input)": "Σ prompt_tokens / wall_min",
    "TPM(uncached-input)": "Σ max(0, prompt_tokens_i − cached_tokens_i) / wall_min",
    "TPM(device-work)": "(Σ 实际未命中输入 token + Σ output_tokens) / wall_min",
    "TPM(decode)": "Σ output_tokens / wall_min",
    "TPM(expected-uncached-input)": "Σ uncached_expected_i / wall_min（按数据集标注估算）",
}


def classify(err):
    if not err:
        return None
    e = str(err)
    for p in (ERR_INFRA, ERR_HARNESS_DATA, ERR_HARNESS_RENDER):
        if e.startswith(p):
            return p
    return ERR_ENGINE


def jl(path):
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                yield json.loads(line)


def q(v, x):
    v = sorted(y for y in v if y is not None)
    return v[min(len(v) - 1, int(x * len(v)))] if v else None


def qs(v, ql=(.5, .9, .95, .99)):
    return {("p%d" % int(x * 100)): q(v, x) for x in ql}


def phase_gate(row):
    """该请求适用的 TTFT p95 闸门值（秒）。链首走 30s。

    ★ 链内序号在两条路径下**键名不同**：构建期内存行是 `_idx_in_chain`（下划线前缀），
      而 loadgen 落盘的 raw 记录是 `idx_in_chain`。**必须两个都认。**
      只认一个的后果（实测于真实 cohort）：scorer 永远看不到 index 0 ->
      `chain_start` 门只能靠 `phase == "context_reset"` 填充（n=17），
      而真正的 97 条链首被错判进 `intra(<=3s)` 门（75 条）与 `turn_start(<=15s)` 门（7 条）。
      被错配请求的 uncached_expected p50 = 34,170，是 intra 其余请求（1,470）的 **23.2 倍**，
      最高 260,770 —— 即标着「chain/session-start」的那道门从未测过链首。

    ★ `phase_basis == "dataset"` 时，数据集声明的 `phase` **优先于链内序号**。
      加这条是因为 shrimp-ds41flash 包里"用户轮次开始"就等于"新 workflow 起手"：
      次级 workflow 的链首既是序号 0、又确实是用户新起的一轮，不特殊处理则
      `turn_start` 门永远为空（该集实测 0 条）。带该标记才生效，所以其它数据集
      （含 S1-Real-v2 已发布集）的行为逐字节不变。
    """
    if row.get("phase_basis") == "dataset" and row.get("phase") == "turn_start":
        return P95_TURN_START_S
    idx = row.get("_idx_in_chain")
    if idx is None:
        idx = row.get("idx_in_chain")
    if idx == 0:
        return P95_CHAIN_START_S
    ph = row.get("phase")
    if ph == "turn_start":
        return P95_TURN_START_S
    if ph == "context_reset":
        return P95_CHAIN_START_S
    return P95_INTRA_S


def in_ttft_gate(row, selector):
    """返回请求是否属于指定 TTFT 门。

    fast 标签只读取冻结字段 ``uncached_expected``，不随被测部署的实际缓存行为变化。
    overall_intra 包含 fast，是全部 intra 的体验兜底门。
    """
    # 前缀载体（prefix_carrier）只负责把缓存预热到生产状态，本身不进任何门：
    # turn_start 头单独重放时缓存是空的，测出来比生产冷；带上它的 session 前驱重放才等价。
    if row.get("prefix_carrier"):
        return False
    pg = phase_gate(row)
    if selector == "fast_intra":
        return (pg == P95_INTRA_S
                and (row.get("uncached_expected") or 0) <= FAST_INTRA_UNCACHED_MAX)
    if selector == "overall_intra":
        return pg == P95_INTRA_S
    if selector == "r3_intra":
        return pg == P95_INTRA_S and row.get("intra_role") == "R3"
    if selector == "turn_start":
        return pg == P95_TURN_START_S
    if selector == "chain_start":
        return pg == P95_CHAIN_START_S
    raise ValueError("unknown TTFT gate selector: %s" % selector)


# --------------------------------------------------------------------------- #
# 数据装载
# --------------------------------------------------------------------------- #
def load_index(root, include_all=False):
    """返回 (rows_by_req_id, chains_by_id, reqs_by_chain)。

    include_all=False 时严格只取 in_serving_load == true（评测运行集）。
    """
    rows, chains = {}, {}
    for r in jl(os.path.join(root, "requests.jsonl")):
        if r["view"] != "canon":
            continue
        if not include_all and not r.get("in_serving_load"):
            continue
        rid = "%s:%s:%s" % (r["pack"], r["view"], r["logical_call_id"])
        r["_req_id"] = rid
        rows[rid] = r
    for c in jl(os.path.join(root, "chains.jsonl")):
        if c["view"] == "canon":
            chains[c["chain_id"]] = c
    grp = collections.defaultdict(list)
    for r in rows.values():
        grp[r["chain_id"]].append(r)
    for cid, rs in grp.items():
        rs.sort(key=lambda x: (x.get("dispatch_offset_ms") or 0, x.get("logical_call_id") or ""))
        for i, r in enumerate(rs):
            r["_idx_in_chain"] = i
    return rows, chains, grp


def serving_accounting(root, sets=("sensitivity-500", "sample-50", "sample-25")):
    """量化「manifest 声明规模」与「in_serving_load 实可跑规模」的落差。

    这是必须随报告给出的口径声明：samples 是按**全部 canon 链**抽的，
    而评测只跑 serving 子集（见方案 §数据来源）。
    """
    allc = {}
    for r in jl(os.path.join(root, "requests.jsonl")):
        if r["view"] == "canon":
            allc["%s:%s:%s" % (r["pack"], r["view"], r["logical_call_id"])] = r
    serv = {k for k, r in allc.items() if r.get("in_serving_load")}
    byc = collections.defaultdict(list)
    for k, r in allc.items():
        byc[r["chain_id"]].append(k)
    out = {}
    for name in sets:
        p = os.path.join(root, "samples", name + ".jsonl")
        if not os.path.exists(p):
            continue
        recs = list(jl(p))
        if name in SAMPLE_DIRECT:
            declared = [q for x in recs for q in (x.get("req_ids") or [])]
        else:                       # 链级集：展开为该链在 requests.jsonl 里的全部 canon 请求
            declared = [k for x in recs for k in byc.get(x["chain_id"], [])]
        usable = [q for q in declared if q in serv]
        drop = collections.Counter(allc[q].get("excluded_reason") or "?"
                                   for q in declared if q not in serv)
        dch = {allc[q]["chain_id"] for q in declared}
        uch = {allc[q]["chain_id"] for q in usable}
        out[name] = {"declared_chains": len(dch), "declared_requests": len(declared),
                     "usable_chains": len(uch), "usable_requests": len(usable),
                     "chains_dropped_entirely": len(dch - uch),
                     "requests_dropped": len(declared) - len(usable),
                     "dropped_by_reason": dict(drop)}
    return out


# --------------------------------------------------------------------------- #
# cohort 冻结（与评审侧已用版本逐字节一致；改动会变更 SHA）
# --------------------------------------------------------------------------- #
def _tier(v, edges):
    for i, e in enumerate(edges):
        if v is None or v < e:
            return i
    return len(edges)


def _pick_set(root, name, rows):
    p = os.path.join(root, "samples", name + ".jsonl")
    if not os.path.exists(p):
        sys.exit("找不到抽样集 %s" % p)
    recs = list(jl(p))
    by_chain = collections.defaultdict(list)
    for r in rows.values():
        by_chain[r["chain_id"]].append(r)
    out = []
    for x in recs:
        cid = x["chain_id"]
        if name in SAMPLE_DIRECT:
            rids = [q for q in (x.get("req_ids") or []) if q in rows]
        else:
            rids = [r["_req_id"] for r in sorted(by_chain.get(cid, []),
                                                 key=lambda r: r["_idx_in_chain"])]
        if rids:
            out.append({"chain_id": cid, "req_ids": rids,
                        "stratum": x.get("stratum") or x.get("set_role"),
                        "weight": x.get("weight")})
        else:
            out.append(None)
    return [x for x in out if x]


def freeze_cohort(root, name, rows, seed, path, force=False, accounting=None):
    if os.path.exists(path) and not force:
        return json.load(open(path, encoding="utf-8"))
    base = _pick_set(root, name, rows)
    strata = collections.defaultdict(list)
    for x in base:
        rs = [rows[q] for q in x["req_ids"]]
        head = rs[0]
        key = (head["pack"], head.get("phase") or "?",
               _tier(max((r.get("max_output_i") or 0) for r in rs), (512, 2048, 8192)),
               _tier(max((r.get("uncached_expected") or 0) for r in rs), (4096, 16384, 65536)))
        strata[key].append(x)
    rnd = random.Random(seed)
    for k in strata:
        rnd.shuffle(strata[k])
    keys = sorted(strata, key=lambda k: (-len(strata[k]), k))
    ordered, guard = [], 0
    while any(strata[k] for k in keys):
        for k in keys:
            if strata[k]:
                ordered.append(strata[k].pop())
        guard += 1
        if guard > 10_000_000:
            break
    c = {"cohort_version": COHORT_VERSION, "set": name, "seed": seed,
         "n_chains": len(ordered), "n_requests": sum(len(x["req_ids"]) for x in ordered),
         "n_strata": len(keys), "strata_keys": ["|".join(map(str, k)) for k in keys],
         "chains": ordered}
    if accounting and name in accounting:
        c["serving_load_filter"] = dict(accounting[name], note=(
            "本集在 manifest 里声明的规模是在**全部 canon 请求**上算的；评测只跑 "
            "in_serving_load 子集，故此处规模更小。declared_* 为 manifest 声明值。"))
    c["cohort_sha256"] = hashlib.sha256(
        json.dumps(ordered, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    json.dump(c, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    return c


# --------------------------------------------------------------------------- #
# bodies 物化（body_ref 指向**分片**，必须按 req_id 自行索引）
# --------------------------------------------------------------------------- #
def materialize_bodies(root, wanted):
    want, got = set(wanted), {}
    shards = []
    for dp, _d, fs in os.walk(os.path.join(root, "bodies")):
        shards += [os.path.join(dp, f) for f in fs if f.endswith(".jsonl.gz")]
    shards.sort()
    for si, sp in enumerate(shards, 1):
        if not want - set(got):
            break
        try:
            with gzip.open(sp, "rt", encoding="utf-8") as fh:
                for line in fh:
                    if not line.strip():
                        continue
                    try:
                        b = json.loads(line)
                    except Exception:
                        continue
                    if b.get("req_id") in want and b["req_id"] not in got:
                        got[b["req_id"]] = b
        except Exception as e:
            print("  [warn] 分片读取失败 %s: %r" % (os.path.basename(sp), e), file=sys.stderr)
        print("  物化 %d/%d 分片，已得 %d/%d" % (si, len(shards), len(got), len(want)),
              file=sys.stderr)
    return got


def ensure_bodies(root, wanted, cache_path, use_cache=True):
    bodies = {}
    if use_cache and os.path.exists(cache_path):
        with open(cache_path, encoding="utf-8") as fh:
            for line in fh:
                if line.strip():
                    b = json.loads(line)
                    bodies[b["req_id"]] = b
    if len(bodies) < len(wanted):
        print("[物化] 单遍扫描 bodies（3.4 GB，数分钟）", file=sys.stderr)
        bodies = materialize_bodies(root, wanted)
        os.makedirs(os.path.dirname(cache_path) or ".", exist_ok=True)
        with open(cache_path, "w", encoding="utf-8") as fh:
            for rid in wanted:
                if rid in bodies:
                    fh.write(json.dumps(bodies[rid], ensure_ascii=False) + "\n")
    return bodies


# --------------------------------------------------------------------------- #
# payload 重建（必须与构造侧同一条路径）
# --------------------------------------------------------------------------- #
class Renderer:
    """构造侧用的是 AutoTokenizer + apply_chat_template(tokenize=False,
    add_generation_prompt=True) + encode(add_special_tokens=False)。
    用裸 tokenizers + 自渲染 Jinja 会漏掉 tokenizer_config 的特殊 token 处理。"""

    def __init__(self, tok_dir):
        from transformers import AutoTokenizer
        with open(os.path.join(tok_dir, "chat_template.jinja"), encoding="utf-8") as fh:
            self.chat_template = fh.read()
        self.tokenizer = AutoTokenizer.from_pretrained(
            tok_dir, trust_remote_code=True, local_files_only=True)
        self.tokenizer.chat_template = self.chat_template

    def render(self, body):
        msgs = ([{"role": "system", "content": body["system"]}] if body.get("system") else []) \
               + body.get("messages", [])
        return self.tokenizer.apply_chat_template(
            msgs, tools=body.get("tools") or None,
            tokenize=False, add_generation_prompt=True)

    def n_tokens(self, text):
        return len(self.tokenizer.encode(text, add_special_tokens=False))
