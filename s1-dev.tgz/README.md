# 压测公开开发集 dev-combined-v1

脱敏后的开发集，供提交前自测。311 条会话链、722 个请求。请求正文里的系统提示、工具定义和标识已经替换，正式压测集不在这个包里。

这套负载只能比较自己两次部署的相对变化。它是链前缀抽样，不能当成官方 `N@SLO`。

## 内容

| 路径 | 作用 |
|---|---|
| `requests.jsonl` / `chains.jsonl` / `bodies/` | 请求索引、会话链、脱敏正文 |
| `cohort_ds41-dev-combined-v1.json` | 冻结 cohort，链内容 SHA `52e5657ca8f61109` |
| `harness/` | 发压与评分脚本。不要改请求正文、输出预算或评分脚本 |
| `glm_tok/` | 冻结的 GLM-5.3-Flash tokenizer 与 `chat_template.jinja` |
| `run_dev.py` | 一键跑法：探通 → 预热 → 清 KV → 计量 → 评分 |

运行需要 Linux 上的 Python 3，以及能本地加载这个 tokenizer 的 `transformers`。tokenizer 只读包内文件，不访问外网。

## 怎么跑

```bash
wenyon-cli dataset download s1-dev-combined-v1-redacted -o ./dev-combined-v1
cd dev-combined-v1
python3 run_dev.py \
  --base-url http://<你的服务>:8000 \
  --n 6 \
  --out runs/dev-n6
```

`--base-url` 写引擎根。地址带 `/v1` 时会先去掉，再请求 `POST /generate`。服务要鉴权时加 `--api-key`，值会放进 `Authorization: Bearer …`，不会写入日志。

脚本依次做：1 条链探通、JIT 预热（不算成绩）、`POST /flush_cache`、正式测量、评分。产物在 `--out` 目录：`report_*.md`、`report_*.json`、`summary.json`。`summary.json` 里有 `evaluation_status`、四道 TTFT p95 和 TPM。

换并发只改 `--n`。自测建议按正式梯子走 `2 / 6 / 10 / 14 / 18 / 22 / …`（从 2 起每隔 4）。换 N 之前必须重新清 KV，否则上一档的前缀缓存会把 TTFT 冲好看。同一台引擎上可以加 `--skip-warmup` 复用预热，KV 不能复用。

`summary.json` 没有 `tpot_mean`。第二顺位要看的 TPOT 是：取「客户端首个带输出的 SSE 到最后一个 SSE」和「服务端首 token 时刻到客户端收完」这两段里更长的一段，再除以 `output_tokens - 1`，然后取该档均值。`report_*.json` 里的 `tpot` 只含第一段。

加了 `--max-chains`、`--no-gap` 或 `--include-all` 之后，跑的就不是这份冻结负载，结果不能拿来对比。
