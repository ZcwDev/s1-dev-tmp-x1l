#!/usr/bin/env python3
"""S1-Real-v2 **评测脚本**（只负责判分与报告，不施压）。

输入：s1_loadgen.py 产出的 `raw_*.jsonl` + `run_*.json`
产出：`report_<set>_N<n>_<ts>.json`（机器可读）+ `report_<set>_N<n>_<ts>.md`（人读）

可对同一批原始量**反复重跑**（改阈值、加分层、复核），不必重新施压。

判据与口径（与《压测方案》一致）：
  · 服务硬门 10 条：coverage / 四类错误 / fast+overall intra /
    turn_start / chain_start p95 / 门样本前置条件
  · formal 通道额外要求服务端 TTFT 打点覆盖率 100%
  · budget_attainment **不是硬门**（两个通道都是），只作诊断 + 80% 绊线
  · 固定输出 TPM 族（5 必出 + 1 补充）与参考指标（RPM / 平均 active occupancy /
    cache-hit ratio / wall time / 完成请求数），**均不构成 SLO 硬门**
"""
from __future__ import annotations

import argparse
import collections
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s1_common import (BUDGET_BASE_S, BUDGET_RATE, BUDGET_TRIPWIRE,  # noqa: E402
                       CHAIN_START_GATE, ERR_HARNESS_DATA, ERR_HARNESS_RENDER,
                       GATES, OCCUPANCY_MIX, P95_CHAIN_START_S, TPM_FORMULAS,
                       TPM_LABELS, TTFT_GATE_SPECS, in_ttft_gate, phase_gate, q, qs,
                       stamp_intra_roles, ttft_gate_specs)

# --------------------------------------------------------------------------- #
# 稳态窗口 TPM 与月产值
# --------------------------------------------------------------------------- #
#: 固定稳态窗口：W = [t0 + start_min, t0 + start_min + len_min)
#: 前段作为 ramp-up、后段避开 cohort drain-tail；分母固定为 len_min 分钟。
STEADY_START_MIN = 10
STEADY_LEN_MIN = 60
STEADY_SUBWINDOWS = 6          # 把 W 等分成 6 段，要求每段都有到达（rpm>0 全程成立）

#: GLM-5.3-Flash 计价（USD / 1M tokens）。禁止用 TPM(ALL) × 单一混合价格。
PRICE_CACHED_INPUT = 0.03
PRICE_UNCACHED_INPUT = 0.15
PRICE_OUTPUT = 0.50
USD_CNY = 7.1

BAND_UNC = ("<4K", "4-16K", "16-64K", ">=64K")
BAND_HIT = ("low(<50%)", "mid(50-90%)", "high(>=90%)")
LEN_TIERS = ((0, 32768, "<32K"), (32768, 65536, "32-64K"), (65536, 131072, "64-128K"),
             (131072, 262144, "128-256K"), (262144, 1 << 62, ">256K"))


def band(v, edges):
    for i, e in enumerate(edges):
        if v is None or v < e:
            return i
    return len(edges)


def jl(p):
    with open(p, encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                yield json.loads(line)


def _abs_ts(rec, *keys):
    """取绝对时间戳（epoch 秒）；非 epoch 值（如 perf_counter）一律视为缺失。"""
    for k in keys:
        v = rec.get(k)
        if isinstance(v, (int, float)) and v > 1e9:
            return float(v)
    return None


def _steady_window(ok, wall, cfg):
    """固定稳态窗口内的真实 token 处理速率 + 月产值。

    与 `rep["tpm"]`（有限 cohort 全程平均，诊断用）是**两种计量语义**，不可混用：
    月产值只能取本函数的输出。
    """
    start_min = float(cfg.get("steady_start_min") or STEADY_START_MIN)
    len_min = float(cfg.get("steady_len_min") or STEADY_LEN_MIN)
    rep = {"window_rule": "[t0 + %g min, t0 + %g min)" % (start_min, start_min + len_min),
           "start_min": start_min, "len_min": len_min, "denominator_minutes": len_min,
           "pricing_usd_per_mtok": {"cached_input": PRICE_CACHED_INPUT,
                                    "uncached_input": PRICE_UNCACHED_INPUT,
                                    "output": PRICE_OUTPUT},
           "usd_cny": USD_CNY,
           "is_monthly_value_source": True}

    # 归属基准：服务端 t_recv_s 覆盖 100% 时优先，否则退回 client_dispatch_at_s
    n_srv = sum(1 for r in ok if _abs_ts(r, "t_recv_s") is not None)
    basis = "server_t_recv_s" if (ok and n_srv == len(ok)) else "client_dispatch_at_s"
    key = "t_recv_s" if basis == "server_t_recv_s" else "client_dispatch_at_s"
    stamped = [(r, _abs_ts(r, key)) for r in ok]
    miss = [r for r, t in stamped if t is None]
    rep["attribution_basis"] = basis
    rep["n_successful"] = len(ok)
    rep["n_without_timestamp"] = len(miss)

    if not ok or miss:
        rep["validity"] = {"ok": False, "reason": (
            "raw 缺少可用于窗口归属的绝对时间戳（缺 %d/%d）。"
            "loadgen 必须无条件记录 client_dispatch_at_s / client_first_token_at_s / "
            "client_finish_at_s，或由引擎提供 t_recv_s。" % (len(miss), len(ok)))}
        for k in ("cached_input", "uncached_input", "input", "decode", "device_work", "all"):
            rep["tpm_" + k] = None
        rep["monthly_value"] = None
        return rep

    ts_all = [t for _, t in stamped]
    t0, t_last = min(ts_all), max(ts_all)
    W0, W1 = t0 + start_min * 60.0, t0 + (start_min + len_min) * 60.0
    rep["t0_s"] = t0
    rep["window_start_s"], rep["window_end_s"] = W0, W1
    rep["cohort_span_min"] = (t_last - t0) / 60.0

    inw = [(r, t) for r, t in stamped if W0 <= t < W1]
    rep["n_in_window"] = len(inw)
    rep["n_outside_window"] = len(ok) - len(inw)
    rep["rpm"] = len(inw) / len_min if len_min else None

    # 有效性前置：W 必须整段处于"仍在供给"的状态，否则又是在排空段里算平均
    sub = [0] * STEADY_SUBWINDOWS
    width = (W1 - W0) / STEADY_SUBWINDOWS
    for _, t in inw:
        i = min(STEADY_SUBWINDOWS - 1, int((t - W0) / width)) if width > 0 else 0
        sub[i] += 1
    checks = {
        "has_requests_in_window": len(inw) > 0,
        "all_subwindows_nonempty": all(c > 0 for c in sub),
        "cohort_not_drained_before_window_end": t_last >= W1,
    }
    rep["subwindow_request_counts"] = sub
    if not all(checks.values()):
        rep["validity"] = {"ok": False, "checks": checks, "reason": (
            "窗口无效：" + ", ".join(k for k, v in checks.items() if not v)
            + "。该次运行不得据此发布 TPM/月产值（应改窗口或扩大 cohort 供给跨度）。")}
        for k in ("cached_input", "uncached_input", "input", "decode", "device_work", "all"):
            rep["tpm_" + k] = None
        rep["monthly_value"] = None
        return rep

    cached = sum(r.get("cached_tokens") or 0 for r, _ in inw)
    prompt = sum(r.get("prompt_tokens") or 0 for r, _ in inw)
    uncached = sum(max(0, (r.get("prompt_tokens") or 0) - (r.get("cached_tokens") or 0))
                   for r, _ in inw)
    out = sum(r.get("output_tokens") or 0 for r, _ in inw)
    rep.update({
        "tpm_cached_input": cached / len_min,
        "tpm_uncached_input": uncached / len_min,
        "tpm_input": (cached + uncached) / len_min,
        "tpm_decode": out / len_min,
        "tpm_device_work": (uncached + out) / len_min,
        "tpm_all": (cached + uncached + out) / len_min,
        "tpm_expected_uncached_input": (sum(r.get("uncached_expected") or 0
                                            for r, _ in inw) / len_min),
        "tokens_in_window": {"cached_input": cached, "uncached_input": uncached,
                             "input": cached + uncached, "decode": out},
        # token 加权命中率（按 token 计，不是按请求平均）
        "token_weighted_cache_hit": (cached / prompt) if prompt else None,
        "avg_active_occupancy": (sum(r.get("wall_s") or 0 for r, _ in inw) / (len_min * 60.0)),
    })
    usd_min = (cached * PRICE_CACHED_INPUT + uncached * PRICE_UNCACHED_INPUT
               + out * PRICE_OUTPUT) / 1e6 / len_min
    rep["monthly_value"] = {
        "usd_per_min": usd_min,
        "usd_per_month": usd_min * 60 * 24 * 30,
        "cny_per_month": usd_min * 60 * 24 * 30 * USD_CNY,
        "formula": "cached×0.03 + uncached×0.15 + output×0.50 (USD/1M) → /min → ×60×24×30",
    }
    rep["validity"] = {"ok": True, "checks": checks}
    return rep


def evaluate(recs, wall, cfg):
    n = len(recs)
    # 前缀载体（只预热缓存、不进任何门）单独剥离并计数：既不要污染 coverage/时延统计，
    # 也不能把它们的错误藏起来（单独报 n_error）。
    carriers = [r for r in recs if r.get("prefix_carrier")]
    recs = [r for r in recs if not r.get("prefix_carrier")]
    n_carrier_err = sum(1 for r in carriers if r.get("error"))
    cls = collections.Counter(r.get("error_class") for r in recs if r.get("error_class"))
    dispatched = [r for r in recs
                  if r.get("error_class") not in (ERR_HARNESS_DATA, ERR_HARNESS_RENDER)]
    ok = [r for r in dispatched if not r.get("error")]

    rep = {"config": cfg, "wall_s": wall, "n_attempted": n, "n_dispatched": len(dispatched),
           "prefix_carriers": {"n": len(carriers), "n_error": n_carrier_err,
                               "note": "只预热缓存；已从 coverage/时延/门判定中剥离"},
           "error_counts": dict(cls),
           "harness_error_rate": ((cls[ERR_HARNESS_DATA] + cls[ERR_HARNESS_RENDER]) / n)
                                 if n else None,
           "service_error_rate": (cls["ENGINE"] / len(dispatched)) if dispatched else None,
           "infra_error_rate": (cls["INFRA"] / len(dispatched)) if dispatched else None}

    # ---- 逐请求判据：budget / slack（诊断）----
    judged, unjudgeable = [], 0
    for r in ok:
        if r.get("prompt_tokens") is None or r.get("cached_tokens") is None \
                or r.get("ttft_s") is None:
            unjudgeable += 1
            continue
        unc = max(0, r["prompt_tokens"] - r["cached_tokens"])
        bud = BUDGET_BASE_S + unc / BUDGET_RATE
        judged.append({"r": r, "unc": unc, "budget": bud,
                       "pass": r["ttft_s"] <= bud, "slack": bud - r["ttft_s"],
                       "w": r.get("sampling_weight") or 0.0})
    rep["n_judged"] = len(judged)
    rep["n_unjudgeable"] = unjudgeable
    rep["coverage"] = (len(judged) / len(dispatched)) if dispatched else None

    sw = sum(d["w"] for d in judged) or 0.0
    att_unw = (sum(1 for d in judged if d["pass"]) / len(judged)) if judged else None
    att_w = (sum(d["w"] for d in judged if d["pass"]) / sw) if sw else None
    authoritative = att_w if cfg.get("lane") == "formal" else att_unw
    rep["budget_attainment"] = {
        "unweighted": att_unw, "weighted": att_w,
        "authoritative_for_lane": ("weighted" if cfg.get("lane") == "formal" else "unweighted"),
        "is_slo_gate": False,
        "note": "**不是硬门**（两个通道都不是）。dev 以 unweighted 为准；formal 做加权总体推断时以 weighted 为准。",
        "tripwire": {"threshold": BUDGET_TRIPWIRE, "triggered": (
            authoritative is not None and authoritative < BUDGET_TRIPWIRE),
            "meaning": "低于绊线时本档需**解释**（通常指向固定开销偏高或冷 prefill 率偏低），但不否决。"},
    }
    rep["slack_s"] = qs([d["slack"] for d in judged]) if judged else None
    rep["implied_prefill_tok_s"] = qs(
        [d["unc"] / max(1e-6, d["r"]["ttft_s"] - BUDGET_BASE_S) for d in judged
         if d["r"]["ttft_s"] > BUDGET_BASE_S]) if judged else None
    rep["uncached_actual_vs_expected_rel_dev"] = qs(
        [((max(0, (r["prompt_tokens"] or 0) - (r["cached_tokens"] or 0)))
          - (r.get("uncached_expected") or 0)) / max(1, r.get("uncached_expected") or 1)
         for r in ok if r.get("prompt_tokens") is not None
         and r.get("cached_tokens") is not None and r.get("uncached_expected")]) or None

    # ---- 相位闸门（含可评估性与 TTFT 基准）----
    # 背景：call_engine 在拿不到服务端打点时会**逐请求**回退到客户端首 SSE。
    # 两种口径不在同一基准上（服务端不含网络/gateway），混在一起算 p95 不是同一个统计量。
    # 处理原则：**两种基准都算、都报，并标出是否冲突；默认不据此改判**（避免改写已在跑的结论），
    # 需要严口径时用 --strict-ttft-basis 让 ALL_PASS 额外要求无冲突。
    n_server = sum(1 for r in ok if r.get("ttft_source") == "server")
    n_proxy = sum(1 for r in ok if r.get("ttft_source") == "client_proxy")
    n_unknown = len(ok) - n_server - n_proxy
    # R3 角色从本次运行自己的链首行推（对已跑过的运行也生效）；无 R3 样本时门单不变。
    rep["intra_role_warnings"] = {"n_unknown_head": stamp_intra_roles(ok)}
    specs = ttft_gate_specs(ok)
    gv = {k: [r["ttft_s"] for r in ok if in_ttft_gate(r, selector)]
          for k, selector, lim in specs}
    gv_srv = {k: [r["ttft_s"] for r in ok
                  if in_ttft_gate(r, selector) and r.get("ttft_source") == "server"]
              for k, selector, lim in specs}
    rep["ttft_p95_by_gate"] = {k: q(v, .95) for k, v in gv.items()}
    # p95 在样本很少时不是可用的统计量：n=4 的 p95 就是最大值本身。
    # 只作**告警**，不改变 evaluable/pass —— 避免改写正在跑的结论。
    MIN_N_FOR_P95 = 20
    rep["ttft_gate_detail"] = {
        k: {"n": len(gv[k]), "p95": q(gv[k], .95), "limit_s": lim,
            "evaluable": len(gv[k]) > 0,
            "pass": (q(gv[k], .95) <= lim) if gv[k] else None,
            "n_server_only": len(gv_srv[k]), "p95_server_only": q(gv_srv[k], .95),
            "pass_server_only": ((q(gv_srv[k], .95) <= lim) if gv_srv[k] else None),
            "min_n_for_p95": MIN_N_FOR_P95,
            "underpowered": 0 < len(gv[k]) < MIN_N_FOR_P95,
            "n_at_or_above_p95": max(0, len(gv[k]) - int(.95 * len(gv[k])))
                                 if gv[k] else 0,
            "p95_uncached": q([r.get("uncached_expected") or 0
                               for r in ok if in_ttft_gate(r, selector)], .95),
            "shape_pressure_reference_tok_s": ((q([r.get("uncached_expected") or 0
                                                  for r in ok
                                                  if in_ttft_gate(r, selector)], .95) or 0) / lim)
                                             if gv[k] else None}
        for k, selector, lim in specs}
    rep["ttft_gate_warnings"] = [k for k, d in rep["ttft_gate_detail"].items()
                                 if d["underpowered"]]

    # ---- 3. chain_start 分层（评审批准，**只报告，不改变总体主门**）----
    # chain_start 门 = 下列条件的**并集**，不等于单纯的会话冷首轮。
    # huge-prefill 是**与上面重叠**的标记，且**仍保留在总体结果中**（不得只放副榜）。
    cs = [r for r in ok if phase_gate(r) == P95_CHAIN_START_S]

    def _cs_group(r):
        et = r.get("edge_type")
        if et == "chain-head":
            return "chain_head_cold_session_start"
        if et == "system-tools-changed":
            return "system_tools_changed"
        if (r.get("phase") or "") == "context_reset":
            return "context_reset"
        return "normal_chain_start"

    grp = collections.defaultdict(list)
    for r in cs:
        grp[_cs_group(r)].append(r)

    def _cs_stat(rs):
        if not rs:
            return {"n": 0}
        u = q([r.get("uncached_expected") or 0 for r in rs], .95)
        return {"n": len(rs), "p95_ttft_s": q([r["ttft_s"] for r in rs], .95),
                "p95_uncached": u,
                "shape_pressure_reference_tok_s": (u / P95_CHAIN_START_S) if u else None,
                "n_zero_cache_hit": sum(1 for r in rs
                                        if (r.get("uncached_expected") or 0)
                                        == (r.get("glm_tokens") or 0))}

    rep["chain_start_definition"] = {
        "logical_chain_head": "idx_in_chain == 0（回放实际发送的该链第一条）",
        "cold_session_start": "edge_type == 'chain-head'（会话首次，零缓存命中）",
        "system_tools_changed": "edge_type == 'system-tools-changed'（system/tools 变更导致重新切链，"
                                "该请求 prompt 前缀与任何已缓存内容都不同 -> 结构性零命中）",
        "context_reset": "phase == 'context_reset'（上下文重建）",
        "note": "chain_start(<=30s) 门是以上条件的**并集**，不等于单纯的会话冷首轮；"
                "huge-prefill 是与它们**重叠**的标记，且**仍在总体主门内**。",
    }
    rep["chain_start_strata"] = {
        k: _cs_stat(grp.get(k, [])) for k in
        ("chain_head_cold_session_start", "system_tools_changed",
         "context_reset", "normal_chain_start")}
    huge = [r for r in cs if (r.get("uncached_expected") or 0) > 65536]
    rep["chain_start_huge_prefill_overlap"] = dict(
        _cs_stat(huge), threshold_uncached=65536,
        note="与上面的分层**重叠**的子集；仍计入总体 chain_start 主门，不得仅作副榜。")
    rep["chain_start_strata_total"] = _cs_stat(cs)
    _conf = [k for k, selector, lim in specs
             if rep["ttft_gate_detail"][k]["pass"] is not None
             and rep["ttft_gate_detail"][k]["pass_server_only"] is not None
             and rep["ttft_gate_detail"][k]["pass"]
             != rep["ttft_gate_detail"][k]["pass_server_only"]]
    rep["ttft_basis"] = {
        "n_successful": len(ok), "n_server": n_server, "n_client_proxy": n_proxy,
        "n_unknown": n_unknown,
        "server_coverage": (n_server / len(ok)) if ok else None,
        "mixed_basis": bool(n_server and n_proxy),
        "conflicting_gates": _conf,
        "conflict": bool(_conf),
        "note": ("gate 用逐请求 ttft_s（服务端优先、缺失时回退客户端首 SSE）。"
                 "若两基准对同一门给出不同结论，该档判定**依赖基准**，须在报告中显式说明；"
                 "默认不改判（保持与在跑结论可比），--strict-ttft-basis 时并入 ALL_PASS。"),
    }
    rep["ttft_p95_by_phase"] = {
        k: q([r["ttft_s"] for r in ok if (r.get("phase") or "?") == k], .95)
        for k in sorted({(r.get("phase") or "?") for r in ok})}
    rep["ttft_by_len_tier"] = {}
    for lo, hi, name in LEN_TIERS:
        v = [r["ttft_s"] for r in ok
             if r.get("prompt_tokens") is not None and lo <= r["prompt_tokens"] < hi]
        rep["ttft_by_len_tier"][name] = {"n": len(v), **qs(v)}
    rep["tpot"] = qs([r.get("tpot_s") for r in ok])

    # ---- 缓存（与 TTFT 同级上报）----
    hs = [r["cached_tokens"] / r["prompt_tokens"] for r in ok
          if r.get("prompt_tokens") and r.get("cached_tokens") is not None]
    rep["cache_hit_ratio"] = qs(hs) if hs else None
    bh = collections.defaultdict(list)
    for r in ok:
        if not r.get("prompt_tokens") or r.get("cached_tokens") is None \
                or r.get("ttft_s") is None:
            continue
        bh[BAND_HIT[band(r["cached_tokens"] / r["prompt_tokens"], (0.5, 0.9))]].append(r["ttft_s"])
    rep["ttft_p95_by_hit_band"] = {k: {"n": len(v), **qs(v)} for k, v in sorted(bh.items())}

    # ---- budget attainment 分层（诊断）----
    st = collections.defaultdict(lambda: [0, 0])
    for d in judged:
        r = d["r"]
        for axis, key in (("phase", r.get("phase") or "?"),
                          ("uncached_band", BAND_UNC[band(d["unc"], (4096, 16384, 65536))]),
                          ("hit_band", BAND_HIT[band((r.get("cached_tokens") or 0)
                                                     / max(1, r.get("prompt_tokens") or 1),
                                                     (0.5, 0.9))])):
            c = st[(axis, key)]
            c[0] += 1
            c[1] += 1 if d["pass"] else 0
    rep["budget_attainment_stratified"] = {
        "%s|%s" % k: {"n": v[0], "attainment": (v[1] / v[0]) if v[0] else None}
        for k, v in sorted(st.items())}

    # ---- 稳态窗口 TPM（**主口径**）----
    # 尾部长链在 replay_gap 里空等数小时，若以全程墙钟为分母会系统性压低 TPM/月产值，
    # 且各 N 的 drain-tail 污染程度不同。故主 TPM 一律取固定稳态窗口。
    rep["tpm_steady_window"] = _steady_window(ok, wall, cfg)

    # ---- TPM 族（固定 schema；主口径 = 稳态窗口）----
    wm = wall / 60.0 if wall else 0.0
    t_in = sum(r.get("prompt_tokens") or 0 for r in ok)
    t_out = sum(r.get("output_tokens") or 0 for r in ok)
    t_unc = sum(max(0, (r.get("prompt_tokens") or 0) - (r.get("cached_tokens") or 0))
                for r in ok)
    t_unc_exp = sum(r.get("uncached_expected") or 0 for r in ok)
    busy = sum(r.get("wall_s") or 0 for r in ok)
    # 旧口径：全程墙钟 —— 只作诊断/历史对照
    rep["tpm_finite_cohort_average"] = ({k: None for k in TPM_LABELS.values()} if not wm else {
        "all": (t_in + t_out) / wm,
        "input": t_in / wm,
        "uncached_input_actual": t_unc / wm,
        "device_work": (t_unc + t_out) / wm,
        "decode": t_out / wm,
        "expected_uncached_input": t_unc_exp / wm,
    })
    # 主口径：稳态窗口（见上）。窗口无效时**不发布 TPM**，而不是退回全程平均。
    _sw = rep["tpm_steady_window"]
    _swok = bool(_sw.get("validity", {}).get("ok"))
    rep["tpm"] = ({k: None for k in TPM_LABELS.values()} | {"cached_input": None}
                  if not _swok else {
        "all": _sw["tpm_all"],
        "input": _sw["tpm_input"],
        "uncached_input_actual": _sw["tpm_uncached_input"],
        "device_work": _sw["tpm_device_work"],
        "decode": _sw["tpm_decode"],
        "expected_uncached_input": _sw["tpm_expected_uncached_input"],
        "cached_input": _sw["tpm_cached_input"],
    })
    rep["tpm_semantics"] = (
        "steady-window：分母固定为窗口长度 %g min（W = [t0+%gmin, t0+%gmin)），"
        "**不受 cohort drain-tail 影响**；这是对外发布的 TPM 与月产值口径。"
        "窗口无效时 TPM 为 null（不退回全程平均）。"
        % (cfg.get("steady_len_min") or STEADY_LEN_MIN,
           cfg.get("steady_start_min") or STEADY_START_MIN,
           (cfg.get("steady_start_min") or STEADY_START_MIN)
           + (cfg.get("steady_len_min") or STEADY_LEN_MIN))
        + " 历史对照见 rep['tpm_finite_cohort_average']（诊断）。")
    rep["tpm_labels"] = TPM_LABELS
    rep["tpm_formulas"] = TPM_FORMULAS
    rep["reference_metrics"] = {
        "note": "解释性能的参考指标；**不各自构成 SLO 硬门**。硬门见 rep['gates']。",
        "not_slo_gates": True,
        "rpm": (len(ok) / wm) if wm else None,
        "avg_active_occupancy": (busy / wall) if wall else None,
        "configured_N_slots": cfg.get("N"),
        "cache_hit_ratio": rep["cache_hit_ratio"],
        "cache_hit_ratio_p50": (rep["cache_hit_ratio"] or {}).get("p50"),
        "wall_s": wall, "wall_min": wm if wm else None,
        "completed_requests": len(ok), "dispatched_requests": len(dispatched),
    }

    # ---- 服务端细粒度时间戳 ----
    have_ttft = [r for r in ok if r.get("ttft_source") == "server"
                 and r.get("server_ttft_s") is not None]
    have_breakdown = [r for r in have_ttft if r.get("t_recv_s") is not None
                      and r.get("t_exec_start_s") is not None]
    timing_coverage = len(have_ttft) / len(ok) if ok else 0.0
    rep["server_timing"] = ({"n_with_server_ttft": len(have_ttft),
                             "n_with_breakdown": len(have_breakdown),
                             "n_successful": len(ok),
                             "coverage": timing_coverage,
                             "formal_required_coverage": 1.0,
                             "server_ttft_s": qs([r["server_ttft_s"] for r in have_ttft]),
                             "queue_s": qs([r["t_exec_start_s"] - r["t_recv_s"]
                                            for r in have_breakdown]),
                             "exec_to_first_s": qs([r["t_first_token_s"] - r["t_exec_start_s"]
                                                    for r in have_breakdown
                                                    if r.get("t_first_token_s") is not None]),
                             "ttft_client_s": qs([r["ttft_client_s"] for r in ok
                                                  if r.get("ttft_client_s") is not None])}
                            if have_ttft else
                            {"n_with_server_ttft": 0, "n_with_breakdown": 0,
                             "n_successful": len(ok), "coverage": timing_coverage,
                             "formal_required_coverage": 1.0,
                             "note": "未提供服务端 TTFT；dev 可作为 client proxy 诊断，formal 不可发布。"})

    # ---- 硬门（10 条，两通道相同）----
    gates = {"coverage=100%": rep["coverage"] == 1.0,
             "harness_data==0": cls[ERR_HARNESS_DATA] == 0,
             "harness_render==0": cls[ERR_HARNESS_RENDER] == 0,
             "engine_error<1%": (rep["service_error_rate"] or 0) < 0.01,
             "infra_error<1%": (rep["infra_error_rate"] or 0) < 0.01,
             "gated_phases_have_samples": all(d["evaluable"]
                                             for d in rep["ttft_gate_detail"].values())}
    for k, selector, lim in specs:
        d = rep["ttft_gate_detail"][k]
        gates[k] = bool(d["evaluable"] and d["p95"] is not None and d["p95"] <= lim)
    rep["gates"] = gates
    rep["gates_used"] = (list(GATES) + [k for k, _s, _l in specs if k not in GATES])
    service_gates_pass = all(gates[k] for k in rep["gates_used"])
    formal_timing_pass = cfg.get("lane") != "formal" or timing_coverage == 1.0
    # 7. 评审裁决：formal 必须启用服务端 TTFT（覆盖 100%）并启用 strict basis；
    #    混合基准发生判定冲突时 formal 不得发布。formal 自动启用，无需显式传参。
    strict = bool(cfg.get("strict_ttft_basis")) or cfg.get("lane") == "formal"
    basis_pass = (not rep["ttft_basis"]["conflict"]) if strict else True
    rep["measurement_contract"] = {
        "server_ttft_coverage=100%": formal_timing_pass,
        "required_for_lane": cfg.get("lane") == "formal",
        "strict_ttft_basis": strict,
        "auto_enabled_by_lane": (not bool(cfg.get("strict_ttft_basis"))
                                 and cfg.get("lane") == "formal"),
        "ttft_basis_no_conflict": basis_pass,
    }
    rep["SERVICE_GATES_PASS"] = service_gates_pass
    rep["ALL_PASS"] = service_gates_pass and formal_timing_pass and basis_pass
    rep["evaluation_status"] = "PASS" if rep["ALL_PASS"] else "FAIL"
    rep["execution_status"] = "COMPLETED"
    if not cfg.get("_pressure_window_score_subset") \
            and any(r.get("pressure_window_role") is not None for r in recs):
        rep["pressure_window"] = _pressure_window_block(recs, wall, cfg)
    return rep


def _pressure_window_block(recs, wall, cfg):
    """Score only the frozen ``role=score`` interval of a pressure window.

    Anchor and prelude requests remain visible as execution diagnostics, but
    cannot dilute or improve the pressure-window verdict.  Ordinary cohorts
    never enter this function, so their release scoring is byte-for-byte
    unchanged apart from code layout.
    """
    roles = ("anchor", "prelude", "score")
    bad = sorted({r.get("pressure_window_role") for r in recs
                  if r.get("pressure_window_role") not in roles}, key=str)
    by_role = {}
    for role in roles:
        rs = [r for r in recs if r.get("pressure_window_role") == role]
        ok = [r for r in rs if not r.get("error")]
        dispatched = [r for r in rs
                      if r.get("error_class") not in (ERR_HARNESS_DATA, ERR_HARNESS_RENDER)]
        actual_uncached = [max(0, (r.get("prompt_tokens") or 0)
                                   - (r.get("cached_tokens") or 0))
                           for r in ok if r.get("prompt_tokens") is not None
                           and r.get("cached_tokens") is not None]
        prompt = sum(r.get("prompt_tokens") or 0 for r in ok)
        cached = sum(r.get("cached_tokens") or 0 for r in ok)
        by_role[role] = {
            "n_attempted": len(rs), "n_dispatched": len(dispatched),
            "n_successful": len(ok),
            "error_counts": dict(collections.Counter(
                r.get("error_class") for r in rs if r.get("error_class"))),
            "ttft_s": qs([r.get("ttft_s") for r in ok]),
            "queue_s": qs([r["t_exec_start_s"] - r["t_recv_s"] for r in ok
                            if r.get("t_exec_start_s") is not None
                            and r.get("t_recv_s") is not None]),
            "exec_to_first_s": qs([r["t_first_token_s"] - r["t_exec_start_s"] for r in ok
                                    if r.get("t_first_token_s") is not None
                                    and r.get("t_exec_start_s") is not None]),
            "actual_uncached_tokens": qs(actual_uncached),
            "token_weighted_cache_hit": (cached / prompt) if prompt else None,
        }

    score_recs = [r for r in recs if r.get("pressure_window_role") == "score"]
    stamps = [v for r in score_recs for v in
              (_abs_ts(r, "client_dispatch_at_s", "t_recv_s"),
               _abs_ts(r, "client_finish_at_s")) if v is not None]
    score_wall = (max(stamps) - min(stamps)) if len(stamps) >= 2 else wall
    child_cfg = dict(cfg, _pressure_window_score_subset=True)
    score_rep = evaluate(score_recs, score_wall, child_cfg)
    score_rep["config"].pop("_pressure_window_score_subset", None)
    contracts = sorted({r.get("pressure_window_timing_contract") for r in recs
                        if r.get("pressure_window_timing_contract") is not None})
    contract_consistent = (len(contracts) == 1 and not bad
                           and all(r.get("pressure_window_timing_contract") == contracts[0]
                                   for r in recs))
    return {
        "definition": "anchor/prelude execute for state and pressure; only role=score is scored",
        "timing_contract_sha256": contracts[0] if len(contracts) == 1 else None,
        "timing_contract_consistent": contract_consistent,
        "observed_timing_contracts": contracts,
        "invalid_roles": bad,
        "diagnostics_by_role": by_role,
        "score_wall_s": score_wall,
        "score": score_rep,
    }


def render_md(rep):
    rm, tpm = rep["reference_metrics"], rep["tpm"]
    L = ["# S1-Real-v2 评测报告", ""]
    c = rep["config"]
    L += ["## 结论", "",
          "- **评测判定：%s**" % rep["evaluation_status"],
          "- **评分作业：%s**（成功产出报告，与 PASS/FAIL 分离）" % rep["execution_status"],
          "- 档位：`%s` N=%s，实例 `%s`，cohort `%s`" % (c.get("set"), c.get("N"),
                                                       c.get("instance_id"), c.get("cohort_sha256")),
          ""]
    if rep.get("pressure_window"):
        pw = rep["pressure_window"]
        ps = pw["score"]
        L += ["## Pressure-window 专用裁决", "",
              "- timing contract: `%s`（%s）"
              % (pw.get("timing_contract_sha256") or "invalid/mixed",
                 "PASS" if pw.get("timing_contract_consistent") else "FAIL"),
              "- 只有 `role=score` 进入专用裁决：**%s**（%d requests）"
              % (ps["evaluation_status"], ps["n_attempted"]),
              "- anchor/prelude 仅用于建立状态和连续压力，保留执行诊断，不进入专用分数。", "",
              "| role | attempted | successful | errors |", "|---|---:|---:|---:|"]
        for role in ("anchor", "prelude", "score"):
            d = pw["diagnostics_by_role"][role]
            L.append("| %s | %d | %d | %d |" % (
                role, d["n_attempted"], d["n_successful"],
                sum(d["error_counts"].values())))
        L.append("")
    L += ["## 1. 硬门（10 条，两个通道相同）", "", "| 门 | 结果 |", "|---|---|"]
    for k in rep["gates_used"]:
        L.append("| %s | %s |" % (k, "PASS" if rep["gates"][k] else "**FAIL**"))
    L += ["", "相位门明细（`p95` = 逐请求 ttft_s；`p95(srv)` = 仅服务端打点的子集）：", "",
          "| 门 | n | p95 | p95(srv) | n(srv) | 限值 | 可评估 |", "|---|---:|---:|---:|---:|---:|---|"]
    for k, d in rep["ttft_gate_detail"].items():
        L.append("| %s | %d | %s | %s | %d | %ss | %s |" % (
            k, d["n"],
            ("%.3f" % d["p95"]) if d["p95"] is not None else "—",
            ("%.3f" % d["p95_server_only"]) if d.get("p95_server_only") is not None else "—",
            d.get("n_server_only", 0), d["limit_s"], d["evaluable"]))
    for k, d in rep["ttft_gate_detail"].items():
        if d.get("underpowered"):
            L += ["", "> ⚠️ **%s 门统计上不成立**：n=%d < %d，此时 p95 就是最大值本身，"
                  "该门不应作为定档依据。" % (k, d["n"], d["min_n_for_p95"])]
        if d.get("shape_pressure_reference_tok_s"):
            L += ["", "  - `%s`：p95 请求 uncached=%s，**形状压力参考值** = %.0f tok/s"
                  "（= p95(uncached)/门限；**只是量纲参考，不代表真实所需 prefill 吞吐，"
                  "不可直接用于调度决策**）"
                  % (k, d.get("p95_uncached"), d["shape_pressure_reference_tok_s"])]
    L += ["", "### chain_start 门的上下文分层（**只作报告，不改变总体主门**）", "",
          "`chain_start(≤30s)` 是下列条件的**并集**，不等于单纯的会话冷首轮：", ""]
    cd = rep.get("chain_start_definition") or {}
    for k in ("logical_chain_head", "cold_session_start", "system_tools_changed",
              "context_reset"):
        if cd.get(k):
            L.append("- `%s`：%s" % (k, cd[k]))
    L += ["", "| 分层 | n | p95 TTFT | p95 uncached | 零命中条数 |", "|---|---:|---:|---:|---:|"]
    for k, v in (rep.get("chain_start_strata") or {}).items():
        if not v or not v.get("n"):
            L.append("| %s | 0 | — | — | — |" % k)
            continue
        L.append("| %s | %d | %s | %s | %d |" % (
            k, v["n"], fmt(v.get("p95_ttft_s")), v.get("p95_uncached"),
            v.get("n_zero_cache_hit", 0)))
    hp = rep.get("chain_start_huge_prefill_overlap") or {}
    if hp.get("n"):
        L += ["", "**huge-prefill 重叠子集**（uncached > %s）：n=%d，p95 TTFT=%s，p95 uncached=%s。"
              "**仍计入总体 chain_start 主门。**"
              % (hp.get("threshold_uncached"), hp["n"], fmt(hp.get("p95_ttft_s")),
                 hp.get("p95_uncached"))]
    tt = rep.get("chain_start_strata_total") or {}
    if tt.get("n"):
        L += ["", "分层合计 n=%d（= 总体 chain_start 门规模 %d）"
              % (tt["n"], (rep.get("ttft_gate_detail") or {})
                 .get(CHAIN_START_GATE, {}).get("n", 0))]
    tb = rep.get("ttft_basis") or {}
    if tb:
        L += ["", "**TTFT 基准**：成功 %d 条中服务端 %d / 客户端 proxy %d / 未知 %d（服务端覆盖 %s）"
              % (tb["n_successful"], tb["n_server"], tb["n_client_proxy"], tb["n_unknown"],
                 fmt(tb["server_coverage"]))]
        if tb.get("mixed_basis"):
            L += ["", "> ⚠️ **本档混用了两种 TTFT 基准**（服务端不含网络/网关，客户端首 SSE 含）。"
                  "上表已分别给出两口径的 p95；跨档比较请只与服务端口径比。"]
        if tb.get("conflict"):
            L += ["", "> ⚠️⚠️ **基准冲突：门 `%s` 在两种基准下结论不同 → 本档判定依赖基准。**"
                  "默认未据此改判（保持与在跑结论可比）；如需严口径请加 `--strict-ttft-basis`。"
                  % ", ".join(tb["conflicting_gates"])]
    mc = rep["measurement_contract"]
    L += ["", "formal 测量契约：服务端 TTFT 覆盖 100%% → **%s**%s"
          % ("PASS" if mc["server_ttft_coverage=100%"] else "FAIL",
             "（本通道必需）" if mc["required_for_lane"] else "（dev 仅诊断）")]
    sw = rep.get("tpm_steady_window") or {}
    L += ["", "## 1b. 稳态窗口 TPM 与月产值（**月产值的唯一来源**）", ""]
    if sw.get("validity", {}).get("ok"):
        L += ["- 窗口：`%s`（归属基准 `%s`，窗内 %d 请求，RPM %.2f）"
              % (sw["window_rule"], sw["attribution_basis"], sw["n_in_window"],
                 sw.get("rpm") or 0),
              "- TPM：cached %s / uncached %s / input %s / decode %s / device-work %s / ALL %s"
              % (fmt(sw.get("tpm_cached_input")), fmt(sw.get("tpm_uncached_input")),
                 fmt(sw.get("tpm_input")), fmt(sw.get("tpm_decode")),
                 fmt(sw.get("tpm_device_work")), fmt(sw.get("tpm_all"))),
              "- token 加权缓存命中 %s ｜ 平均 active occupancy %s"
              % (fmt(sw.get("token_weighted_cache_hit")),
                 fmt(sw.get("avg_active_occupancy"))),
              "- 月产值 **$%s / ¥%s**"
              % (fmt((sw.get("monthly_value") or {}).get("usd_per_month")),
                 fmt((sw.get("monthly_value") or {}).get("cny_per_month")))]
    else:
        L += ["> ⚠ **稳态窗口无效，本次不产出 TPM/月产值**：%s"
              % (sw.get("validity", {}).get("reason") or "缺少绝对时间戳")]
    sw2 = rep.get("tpm_steady_window") or {}
    sw_ok = bool(sw2.get("validity", {}).get("ok"))
    L += ["", "## 2. TPM 族（主口径 = **稳态窗口 %g min**；不可互相替代）"
          % (sw2.get("len_min") or STEADY_LEN_MIN), ""]
    if not sw_ok:
        L += ["> ⚠ **稳态窗口无效，本次不发布 TPM/月产值**：%s"
              % (sw2.get("validity", {}).get("reason") or "缺少绝对时间戳"),
              "> 下表因此为空；`tpm_finite_cohort_average` 仅供排查，**不得对外引用**。", ""]
    L += ["| 指标 | 值 | 公式（分母 = 窗口长度，非全程墙钟） |", "|---|---:|---|"]
    for disp, key in rep["tpm_labels"].items():
        v = tpm.get(key)
        formula = rep["tpm_formulas"][disp].replace("wall_min", "window_min")
        L.append("| `%s` | %s | `%s` |" % (disp, ("%.0f" % v) if v is not None else "—",
                                          formula))
    if tpm.get("cached_input") is not None:
        L.append("| `TPM(cached-input)` | %.0f | `Σ cached_tokens / window_min` |"
                 % tpm["cached_input"])
    fca = rep.get("tpm_finite_cohort_average") or {}
    if fca.get("all") is not None:
        L += ["", "> 历史对照（**诊断，禁止用于月产值**）：全程墙钟口径 "
              "`TPM(ALL)` = %.0f，`TPM(decode)` = %.0f；与上表差额即 drain-tail 稀释。"
              % (fca["all"], fca.get("decode") or 0)]
    L += ["", "## 3. 参考指标（**非 SLO 硬门**）", "",
          "| 指标 | 值 |", "|---|---:|",
          "| RPM | %s |" % fmt(rm["rpm"]),
          "| 平均 active occupancy（实测时间平均） | %s |" % fmt(rm["avg_active_occupancy"]),
          "| 配置 N 槽位 | %s |" % rm["configured_N_slots"],
          "| cache-hit ratio p50 | %s |" % fmt(rm["cache_hit_ratio_p50"]),
          "| wall time | %s s |" % fmt(rm["wall_s"]),
          "| 完成请求数 / dispatched | %s / %s |" % (rm["completed_requests"],
                                                     rm["dispatched_requests"]),
          ""]
    L += ["## 4. 缓存与 TTFT 分层", "",
          "cache-hit ratio: `%s`" % json.dumps(rep["cache_hit_ratio"]),
          "", "按命中率分层的 TTFT p95：", ""]
    for k, v in rep["ttft_p95_by_hit_band"].items():
        L.append("- %s（n=%d）：p50=%s p95=%s" % (k, v["n"], fmt(v["p50"]), fmt(v["p95"])))
    L += ["", "按输入长度分档：", ""]
    for k, v in rep["ttft_by_len_tier"].items():
        L.append("- %s（n=%d）：p50=%s p95=%s" % (k, v["n"], fmt(v["p50"]), fmt(v["p95"])))
    L += ["", "## 5. 错误（四类分报）", "",
          "| 类别 | 计数 |", "|---|---:|"]
    for k in ("HARNESS_DATA", "HARNESS_RENDER", "ENGINE", "INFRA"):
        L.append("| %s | %d |" % (k, rep["error_counts"].get(k, 0)))
    L += ["", "coverage = %s" % fmt(rep["coverage"]), ""]
    ba = rep["budget_attainment"]
    L += ["## 6. 诊断项（**不构成硬门**）", "",
          "- budget attainment：unweighted `%s` / weighted `%s`（本通道以 `%s` 为准）"
          % (fmt(ba["unweighted"]), fmt(ba["weighted"]), ba["authoritative_for_lane"]),
          "- 绊线（<%.0f%%）：%s %s" % (ba["tripwire"]["threshold"] * 100,
                                        "**已触发，需解释**" if ba["tripwire"]["triggered"] else "未触发",
                                        "（不否决该档）"),
          "- slack 分位：`%s`" % json.dumps(rep["slack_s"]),
          "- 分层 attainment：%d 格" % len(rep["budget_attainment_stratified"]),
          "- 实际未命中 vs 结构预测（相对偏差）：`%s`"
          % json.dumps(rep["uncached_actual_vs_expected_rel_dev"]),
          ""]
    st = rep["server_timing"]
    if st.get("n_with_server_ttft"):
        L += ["## 7. 服务端时间戳（分离排队与计算）", "",
              "- 服务端 TTFT 打点 %d/%d（%.2f%%）"
              % (st["n_with_server_ttft"], st["n_successful"], st["coverage"] * 100),
              "- server TTFT `%s`" % json.dumps(st["server_ttft_s"]),
              "- queue（recv→exec_start）`%s`" % json.dumps(st["queue_s"]),
              "- exec→first token `%s`" % json.dumps(st["exec_to_first_s"]),
              "- 客户端首 SSE `%s`" % json.dumps(st["ttft_client_s"]), ""]
    L += ["---", "",
          "**前提声明（报 N\\* 时必须一并给出）**",
          "",
          "1. 本评测按 `replay_gap = min(tool_union,300s) + min(net_think,10s)` 驱动，"
          "时间轴相对生产压缩 **45×（biomaster）/ 447×（scimaster）**；",
          "   即**本评测的 1 个 agent ≈ 生产 45–447 个 agent 的负载**。",
          "2. `TPM(decode)` 基于 serving load，**漏掉生产输出总量的 20.7%**"
          "（其中 `long_output_gt_8192` 192 条占 16.03%）——本集不覆盖长输出路径。",
          "3. 开发集**不覆盖 256K 边界**（`sensitivity-500` 无 >256K；全量 serving load 覆盖到 261,849）。",
          "4. 混比口径：occupancy_mix %.3f:%.3f（active_snapshot）。"
          % (OCCUPANCY_MIX["biomaster"], OCCUPANCY_MIX["scimaster"]),
          ""]
    return "\n".join(L)


def fmt(v):
    if v is None:
        return "—"
    return ("%.4f" % v) if isinstance(v, float) and abs(v) < 100 else ("%.1f" % v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True, help="s1_loadgen.py 产出的 raw_*.jsonl")
    ap.add_argument("--run", default="", help="对应的 run_*.json（含 wall 与 config）")
    ap.add_argument("--lane", default="dev", choices=["dev", "formal"])
    ap.add_argument("--out-dir", default="")
    ap.add_argument("--strict-ttft-basis", action="store_true",
                    help="若服务端/客户端两种 TTFT 基准对任一相位门给出不同结论，则 ALL_PASS=False")
    ap.add_argument("--steady-start-min", type=float, default=STEADY_START_MIN,
                    help="稳态窗口起点（相对正式开始的分钟数，默认 %(default)s）")
    ap.add_argument("--steady-len-min", type=float, default=STEADY_LEN_MIN,
                    help="稳态窗口长度（分钟，默认 %(default)s）")
    ap.add_argument("--exit-code-mode", default="gate", choices=["gate", "execution"],
                    help="gate: 评测 FAIL 返回 2；execution: 只要报告产出成功就返回 0")
    args = ap.parse_args()

    recs = list(jl(args.raw))
    run = json.load(open(args.run, encoding="utf-8")) if args.run and os.path.exists(args.run) else {}
    cfg = run.get("config", {})
    cfg["lane"] = args.lane
    cfg["strict_ttft_basis"] = args.strict_ttft_basis
    cfg["steady_start_min"] = args.steady_start_min
    cfg["steady_len_min"] = args.steady_len_min
    wall = run.get("wall_s")
    if wall is None:
        sys.exit("需要 --run 提供 wall_s（TPM 与 RPM 的分母）")
    rep = evaluate(recs, wall, cfg)

    od = args.out_dir or os.path.dirname(os.path.abspath(args.raw))
    os.makedirs(od, exist_ok=True)
    base = os.path.basename(args.raw).replace("raw_", "report_").replace(".jsonl", "")
    jp = os.path.join(od, base + ".json")
    mp = os.path.join(od, base + ".md")
    json.dump(rep, open(jp, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    open(mp, "w", encoding="utf-8").write(render_md(rep))
    print(json.dumps({k: rep[k] for k in ("execution_status", "evaluation_status",
                                          "ALL_PASS", "gates", "measurement_contract", "coverage",
                                          "reference_metrics")},
                     ensure_ascii=False, indent=2))
    print("\n判定：%s\n报告 %s\n      %s" % ("PASS" if rep["ALL_PASS"] else "FAIL", jp, mp))
    if args.exit_code_mode == "execution":
        return 0
    return 0 if rep["ALL_PASS"] else 2


if __name__ == "__main__":
    sys.exit(main())
