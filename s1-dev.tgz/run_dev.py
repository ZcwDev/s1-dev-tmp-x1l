#!/usr/bin/env python3
"""Run the frozen public dev set against one inference service.

Sequence: one-chain preflight, JIT warmup, KV flush, measured replay, score.
``--base-url`` is the engine root (``/generate``). A trailing ``/v1`` is removed.
``--api-key`` is sent as ``Authorization: Bearer <key>`` and is not written to logs.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
HARNESS = HERE / "harness"
DEFAULT_COHORT = HERE / "cohort_ds41-dev-combined-v1.json"
DEFAULT_SET = "dev-combined-v1"


def engine_url(raw: str) -> str:
    return raw.strip().rstrip("/").removesuffix("/v1")


def flush_url(base: str) -> str:
    return engine_url(base) + "/flush_cache"


def _env_flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in {"1", "true", "yes", "on"}


def auth_header(api_key: str) -> str:
    key = api_key.strip()
    if not key or key.lower().startswith("bearer "):
        return key
    return f"Bearer {key}"


def flush_kv(url: str, authorization: str) -> bool:
    if not url:
        return False
    headers = {}
    if authorization:
        headers["Authorization"] = authorization
    try:
        urllib.request.urlopen(
            urllib.request.Request(url, method="POST", headers=headers),
            timeout=30,
        )
        print(f"flushed KV via {url}", flush=True)
        return True
    except OSError as exc:
        print(f"flush failed: {exc}", file=sys.stderr)
        return False


def _latest(directory: Path, pattern: str) -> Path | None:
    matches = sorted(directory.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    return matches[0] if matches else None


def _run(cmd: list[str], log: Path, env: dict[str, str]) -> int:
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("w", encoding="utf-8") as handle:
        proc = subprocess.run(
            cmd,
            cwd=str(HARNESS),
            env=env,
            stdout=handle,
            stderr=subprocess.STDOUT,
            check=False,
        )
    return proc.returncode


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--base-url",
        default=os.environ.get("BASE_URL") or os.environ.get("S1_ENGINE_URL") or "",
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("API_KEY") or os.environ.get("S1_API_KEY") or "",
    )
    parser.add_argument("--n", type=int, default=int(os.environ.get("N") or 6))
    parser.add_argument("--model", default=os.environ.get("S1_MODEL") or "glm-5.3-flash")
    parser.add_argument("--root", default=str(HERE))
    parser.add_argument("--out", default=os.environ.get("S1_OUT") or "runs/dev")
    parser.add_argument("--tok-dir", default=str(HERE / "glm_tok"))
    parser.add_argument("--cohort", default=str(DEFAULT_COHORT))
    parser.add_argument("--set", default=DEFAULT_SET)
    parser.add_argument("--warmup-min-chains", type=int, default=16)
    parser.add_argument("--skip-warmup", action="store_true", default=_env_flag("S1_SKIP_WARMUP"))
    parser.add_argument("--skip-preflight", action="store_true", default=_env_flag("S1_SKIP_PREFLIGHT"))
    args = parser.parse_args(argv)

    base = engine_url(args.base_url)
    if not base:
        print("BASE_URL / --base-url is required", file=sys.stderr)
        return 2
    root = Path(args.root)
    cohort = Path(args.cohort)
    if not (root / "requests.jsonl").is_file():
        print(f"dataset missing requests.jsonl under {root}", file=sys.stderr)
        return 2
    if not cohort.is_file():
        print(f"missing cohort {cohort}", file=sys.stderr)
        return 2
    if not (HARNESS / "s1_loadgen.py").is_file():
        print(f"missing harness at {HARNESS}", file=sys.stderr)
        return 2

    out = Path(args.out)
    if not out.is_absolute():
        out = Path.cwd() / out
    out.mkdir(parents=True, exist_ok=True)
    authorization = auth_header(args.api_key)
    env = os.environ.copy()
    env["S1_ENGINE_URL"] = base
    if authorization:
        env["S1_ENGINE_AUTH_TOKEN"] = authorization
    stamp = str(int(time.time()))
    tag = f"{args.set}-{stamp}"
    loadgen = [sys.executable, str(HARNESS / "s1_loadgen.py")]
    common = [
        "--root",
        str(root),
        "--cohort-file",
        str(cohort),
        "--set",
        args.set,
        "--n",
        str(args.n),
        "--model",
        args.model,
        "--tok-dir",
        args.tok_dir,
        "--out-dir",
        str(out),
    ]
    if not args.skip_preflight:
        rc = _run(
            [
                *loadgen,
                *common,
                "--instance-id",
                f"{tag}-preflight",
                "--cache-namespace",
                f"{tag}-preflight",
                "--max-chains",
                "1",
                "--no-gap",
                "--checkpoint-every",
                "0",
            ],
            out / "preflight.log",
            env,
        )
        if rc != 0:
            print(f"preflight failed rc={rc} see {out / 'preflight.log'}", file=sys.stderr)
            return rc

    if not args.skip_warmup:
        rc = _run(
            [
                *loadgen,
                *common,
                "--instance-id",
                f"{tag}-warmup",
                "--cache-namespace",
                f"{tag}-jit",
                "--warmup",
                "--warmup-min-chains",
                str(args.warmup_min_chains),
            ],
            out / "warmup.log",
            env,
        )
        if rc != 0:
            print(f"warmup failed rc={rc} see {out / 'warmup.log'}", file=sys.stderr)
            return rc

    flush = env.get("S1_FLUSH_URL", "").strip() or flush_url(base)
    if not flush_kv(flush, authorization):
        print(f"refusing to measure on a dirty cache; flush failed: {flush}", file=sys.stderr)
        return 1

    t0 = time.time()
    rc = _run(
        [
            *loadgen,
            *common,
            "--instance-id",
            f"{tag}-measure",
            "--cache-namespace",
            f"{tag}-measure",
        ],
        out / "loadgen.log",
        env,
    )
    wall = int(time.time() - t0)
    (out / "WALL_SECONDS").write_text(f"{wall}\n", encoding="utf-8")
    if rc != 0:
        print(f"loadgen failed rc={rc} see {out / 'loadgen.log'}", file=sys.stderr)
        return rc

    raw = _latest(out, "raw_*.jsonl")
    run = _latest(out, "run_*.json")
    if raw is None or run is None:
        print("loadgen produced no raw/run files", file=sys.stderr)
        return 1
    score_rc = _run(
        [
            sys.executable,
            str(HARNESS / "s1_score.py"),
            "--raw",
            str(raw),
            "--run",
            str(run),
            "--lane",
            "dev",
            "--out-dir",
            str(out),
            "--exit-code-mode",
            "execution",
        ],
        out / "score.log",
        env,
    )
    report = _latest(out, "report_*.json")
    summary = {
        "set": args.set,
        "n": args.n,
        "wall_s": wall,
        "raw": str(raw),
        "run": str(run),
        "report": str(report) if report else None,
        "score_rc": score_rc,
    }
    if report and report.is_file():
        payload = json.loads(report.read_text(encoding="utf-8"))
        summary["evaluation_status"] = payload.get("evaluation_status")
        summary["ttft_p95_by_gate"] = payload.get("ttft_p95_by_gate")
        summary["ALL_PASS"] = payload.get("ALL_PASS")
        summary["tpm"] = payload.get("tpm")
    (out / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({k: summary[k] for k in summary}, ensure_ascii=False))
    return 0 if score_rc == 0 else score_rc


if __name__ == "__main__":
    raise SystemExit(main())
